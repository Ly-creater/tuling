<template>
    <div id="Index">
        <h1>欢迎访问用户权限管理系统</h1>
    </div>
</template>

<script>
    export default {
        name: "Index"
    }
</script>

<style scoped>

</style>