<template>
    <div id="AddMenu">
        <el-dialog title="新增菜单" :modal-append-to-body='false' :visible.sync="dialogFormVisible"  style="width: 1000px;margin-left: 200px"  :center=true>
            <el-form :model="menu"  ref="user">
                <!--                <el-form-item label="菜单类型:" :label-width="formLabelWidth" prop="type" size="small">-->
                <!--                    <el-input v-model="menu.type" auto-complete="off" ></el-input>-->
                <!--                </el-form-item>-->
                <el-form-item label="菜单类型:" :label-width="formLabelWidth" prop="type" size="small">
                    <el-radio-group v-model="menu.menuType">
                        <el-radio label="目录" ></el-radio>
                        <el-radio label="菜单"></el-radio>
                        <el-radio label="功能"></el-radio>
                    </el-radio-group>
                </el-form-item>

                <el-form-item label="菜单名称:" :label-width="formLabelWidth" prop="menuName" size="small">
                    <el-input v-model="menu.menuName" auto-complete="off" ></el-input>
                </el-form-item>
                <el-form-item label="上级菜单:" :label-width="formLabelWidth" prop="parentMenu" size="small">
                    <el-input v-model="menu.parentMenu" auto-complete="off"></el-input>
                </el-form-item>
                <el-form-item label="菜单标识:" :label-width="formLabelWidth" prop="characteristic" size="small">
                    <el-input v-model="menu.characteristic" auto-complete="off"></el-input>
                </el-form-item>
                <el-form-item label="菜单地址:" :label-width="formLabelWidth" prop="address" size="small">
                    <el-input v-model="menu.address" auto-complete="off"></el-input>
                </el-form-item>
                <el-form-item label="排序号:" :label-width="formLabelWidth" prop="sex" size="small">
                    <el-input v-model="menu.orderNum" auto-complete="off"></el-input>
                </el-form-item>
                <el-form-item label="状态:" :label-width="formLabelWidth" prop="menuState" size="small">
                    <el-radio v-model="menu.menuState" label= "有效">有效</el-radio>
                    <el-radio v-model="menu.menuState" label= "无效">无效</el-radio>
                </el-form-item>
                <el-form-item label="备注:" :label-width="formLabelWidth" size="small">
                    <el-input type="textarea" v-model="menu.menuInfo" ></el-input>
                </el-form-item>
            </el-form>
            <div slot="footer" class="dialog-footer">
                <el-button @click="dialogFormVisible = false">取 消</el-button>
                <el-button type="primary" @click="submit">提交</el-button>
            </div>
        </el-dialog>
    </div>
</template>


<script>
    import {addMenu} from '../../network/menu'
    export default {
        name: "AddMenu",
        data() {
            return {
                dialogTableVisible: false,
                dialogFormVisible: false,
                menu: {},
                formLabelWidth: '120px',
            };
        },
        methods: {
            // 表单提交
            submit() {
                addMenu(this.menu).then(res => {
                    this.dialogFormVisible = false
                    let flag = res.data.success;
                    this.$parent.handleselect();
                    flag ?this.$message("添加菜单,"+res.data.message):this.$message.error("添加菜单,"+res.data.message)
                }).catch(err => {
                    this.$message.error("系统错误"+err)
                })
            }
        },
    }
</script>

<style scoped>

</style>