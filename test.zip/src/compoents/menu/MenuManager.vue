<template>
    <span style="width: 100%">
        <MySlot><i class="el-icon-setting">菜单管理</i></MySlot>
<!--        搜索框-->
        <el-card class="box-card">
            菜单名称：<el-input size="small" placeholder="请输入内容" v-model="menu.menuName" style="width: 20%;"></el-input>
              &nbsp;&nbsp;
              &nbsp;&nbsp;
            <span>状态：
                <el-select  size="small" v-model="menu.menuState" placeholder="全部"  style="width:20%">
                    <el-option value="">全部</el-option>
                    <el-option value="有效">有效</el-option>
                    <el-option value="无效">无效</el-option>
                </el-select>
            </span>
            &nbsp;&nbsp;&nbsp;&nbsp;
            <span>菜单类型：
                <el-select  size="small" v-model="menu.menuType" placeholder="全部"  style="width:20%">
                    <el-option value="">全部</el-option>
                    <el-option value="目录">目录</el-option>
                    <el-option value="菜单">菜单</el-option>
                    <el-option value="功能">功能</el-option>
                </el-select>
            </span>
            &nbsp;&nbsp;
            <span>
                <el-button size="mini" type="primary" @click="handleselect">查询</el-button>
                <el-button size="mini" type="success" @click="handleadd">新增</el-button>
                <el-button size="mini" type="danger" @click="handleDeleteAll">删除</el-button>
            </span>
        </el-card>
        <!--        表格-->
        <el-card class="box-card">
            <el-table ref="multipleTable"
                      stripe
                      height="410"
                      @selection-change="handleSelectionChange" :data="menus" tooltip-effect="dark" style="width: 100%" float="left">
            <el-table-column type="selection" width="30" align="center"></el-table-column>
            <el-table-column label="序号" width="50"  align="center">
                <template slot-scope="scope">
                     <span>{{(page - 1) * pageSizes + scope.$index + 1}}</span>
                </template>
            </el-table-column>
            <el-table-column prop="menuName" label="菜单名称" width="80" align="center" ></el-table-column>
            <el-table-column prop="parentMenu" label="上级菜单" width="80" align="center" ></el-table-column>
            <el-table-column prop="menuType" label="菜单类型" width="80" align="center" ></el-table-column>
            <el-table-column prop="characteristic" label="菜单标识" width="110" align="center" ></el-table-column>
            <el-table-column prop="address" label="菜单地址" width="110" align="center" ></el-table-column>
            <el-table-column prop="orderNum" label="排序号" width="105" align="center"  ></el-table-column>
            <el-table-column prop="menuState" label="状态" width="50" align="center" ></el-table-column>
            <el-table-column label="操作" align="center" >
                <template slot-scope="scope"><!--  slot-scope="scope" 这里取到当前单元格  -->
                    <el-button
                            size="mini"
                            type="success"
                            @click="handleadd(scope.row)">新增</el-button>
                    <el-button
                            size="mini"
                            type="primary"
                            @click="handleEdit(scope.row)">修改</el-button>
                    <el-button
                            size="mini"
                            type="danger"
                            @click="handleDelete(scope.row)">删除</el-button>
                </template>
            </el-table-column>
        </el-table>
            <!--        分页组件-->
        <el-pagination
                @size-change="handleSizeChange"
                @current-change="handleCurrentChange"
                :current-page="page"
                :page-sizes="[5, 10, 15, 20]"
                :page-size="100"
                layout="total, sizes, prev, pager, next, jumper"
                :total="totalNum">
        </el-pagination>
        </el-card>
        <AddMenu  ref="AddMenu"></AddMenu>
        <EditMenu  ref="EditMenu"></EditMenu>
    </span>

</template>

<script>
    import * as MenuApi from '../../network/menu'
    import AddMenu from "./AddMenu";
    import EditMenu from "./EditMenu";
    import MySlot from "../MySlot";
    // import addRole from "./addRole";
    export default {
        name: 'Menu',
        components: {
            EditMenu,
            AddMenu,
            MySlot
            // editUser,
        },
        data() {
            return {
                menus: [],
                menu: {},
                multipleTable: [],//选中行的数据
                pageSizes: 5,  //每页显示的数量
                totalNum: 0,  //总数量
                page: 1      //当前页
            }
        },
        created() {
            this.handleselect()
        },
        methods: {
            //查询用户和搜索用户
            handleselect() {
                let params = {
                    menu: this.menu,
                    pageSizes: this.pageSizes,
                    page: this.page,
                    // enablePage: true
                };
                MenuApi.search(params).then(res => {
                    let flag = res.data.success;
                    flag ?this.$message("查询菜单,"+res.data.message):this.$message.error("查询菜单,"+res.data.message)
                    if(res.data.data){
                        this.menus = res.data.data.list;
                        this.totalNum = res.data.data.total;
                        //防止当前页大于最大页数，序号会发生错乱
                        this.page = res.data.data.pageNum;
                    }
                }).catch(err => {
                    this.$message.error("系统错误" + err)
                })
            },

            handleSizeChange(pageSizes) {
                this.pageSizes = pageSizes;
                this.handleselect()
            },
            handleCurrentChange(page) {
                this.page = page;
                this.handleselect()
            },
            //获取选中行的数据
            handleSelectionChange(val) {
                this.multipleTable = val;               //  this.multipleTable 选中的值
            },
            //日期格式化 yyyy-MM-dd HH:mm:ss
            // dateFormat:function(row,column){
            //     let date = row[column.property]
            //     if(date == undefined)
            //         return ''
            //     return moment(date).format("YYYY-MM-DD HH:mm:ss")
            // },
            //弹窗 修改用户
            handleEdit(item) {
                this.$refs.EditMenu.dialogFormVisible = true
                this.$refs.EditMenu.menu = item
                // console.log(item);
            },
            //弹窗 增加用户
            handleadd() {
                this.$refs.AddMenu.dialogFormVisible = true
            },
            // 删除
            handleDelete(item) {
                this.$confirm(
                    `本次操作将删除"${item.menuName}"菜单，删除后将不可恢复，您确认删除吗？`, {
                        type: 'warning'
                    }
                ).then(() => {
                    MenuApi.deleteMenu(item).then((res) => {
                        this.handleselect();//刷新表格
                        res.data.success ?this.$message("删除菜单,"+res.data.message):this.$message.error("删除菜单,"+res.data.message)
                    }).catch(err => {
                        this.$message.error("系统错误" + err)
                    })
                })
            },
            //批量删除
            handleDeleteAll() {
                this.$confirm(
                    `本次操作将删除所有选中的菜单，删除后账号将不可恢复，您确认删除吗？`, {
                        type: 'warning'
                    }
                ).then(() => {
                    MenuApi.deleteAll(this.multipleTable).then((res) => {
                        this.handleselect();//刷新表格
                        res.data.success ?this.$message("批量删除菜单,"+res.data.message):this.$message.error("批量删除菜单,"+res.data.message)
                    })
                }).catch(err => {
                    this.$message.error("系统错误" + err)
                })
            },
        }
    }
</script>
<style>
</style>