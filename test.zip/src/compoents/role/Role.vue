<template>
    <span style="width: 100%">
        <MySlot><i class="el-icon-document"></i>角色管理</MySlot>
        <!--        搜索框-->
        <el-card class="box-card">
            <span>
                角色名称：<el-input size="small" placeholder="请输入内容" v-model="role.roleName" style="width: 30%"></el-input>
            </span>
            &nbsp;&nbsp;&nbsp;&nbsp;
            <span>状态：
                <el-select size="small" v-model="role.roleState" placeholder="全部" style="width: 30%">
                    <el-option value="">全部</el-option>
                    <el-option value="有效">有效</el-option>
                    <el-option value="无效">无效</el-option>
                </el-select>
            </span>
            &nbsp;&nbsp;&nbsp;&nbsp;
            <span>
                <el-button size="mini" type="primary" @click="handleselect">查询</el-button>
                <el-button size="mini" type="success" @click="handleadd">新增</el-button>
                <el-button size="mini" type="danger" @click="handleDeleteAll">删除</el-button>
            </span>
        </el-card>
        <!--        表格-->
        <el-card class="box-card">
            <el-table ref="multipleTable"
                      stripe
                            height="410"
                          @selection-change="handleSelectionChange" :data="roles" tooltip-effect="dark"
                          style="width: 100%" float="left">
                <el-table-column type="selection" width="60" align="center"></el-table-column>
                <el-table-column label="序号" width="80" align="center">
                    <template slot-scope="scope">
                         <span>{{(page-1) * pageSizes + scope.$index + 1}}</span>
                    </template>
                </el-table-column>
                <el-table-column prop="rid" label="id" width="0" align="center" v-if="false"></el-table-column>
                <el-table-column prop="roleName" label="角色名称" width="120" align="center"></el-table-column>
                <el-table-column prop="roleCode" label="角色编码" width="120" align="center"></el-table-column>
                <el-table-column prop="effectiveDate" label="生效日期" width="100" align="center"></el-table-column>
                <el-table-column prop="expirationDate" label="失效日期" width="100" align="center"></el-table-column>
                <el-table-column prop="roleState" label="状态" width="80" align="center"> </el-table-column>
                <el-table-column label="操作" align="center">
                    <template slot-scope="scope"><!--  slot-scope="scope" 这里取到当前单元格  -->
                        <el-button
                                size="mini"
                                type="primary"
                                @click="handleEdit(scope.row)">修改</el-button>
                        <el-button
                                size="mini"
                                type="danger"
                                @click="handleDelete(scope.row)">删除</el-button>
                        <el-button
                                size="mini"
                                type="warning"
                                @click="handlePermission(scope.row)">设置权限角色</el-button>
                    </template>
                </el-table-column>
            </el-table>
            <!--        分页组件-->
            <el-pagination
                    @size-change="handleSizeChange"
                    @current-change="handleCurrentChange"
                    :current-page="page"
                    :page-sizes="[5, 10, 15, 20]"
                    :page-size="100"
                    layout="total, sizes, prev, pager, next, jumper"
                    :total="totalNum">
            </el-pagination>
        </el-card>

        <EditRole ref="editRole"/>
        <AddRole ref="addRole"/>
        <SetPermission ref="setPermission"/>

    </span>

</template>

<script>
    import moment from 'moment';
    import * as RoleApi from '../../network/role'
    import AddRole from "./AddRole";
    import EditRole from "./EditRole";
    import SetPermission from "./SetPermission";
    import MySlot from "../MySlot";

    export default {
        name: 'Role',
        components: {
            AddRole,
            SetPermission,
            EditRole,
            MySlot
        },
        data() {
            return {
                role: {},
                roles: [],
                multipleTable: [],//选中行的数据
                pageSizes: 10,  //每页显示的数量
                totalNum: 0,  //总数量
                page: 1      //当前页
            }
        },
        created() {
            this.handleselect()
        },
        methods: {
            //查询用户和搜索用户
            handleselect() {
                let params = {
                    role: this.role,
                    pageSizes: this.pageSizes,
                    page: this.page,
                };
                RoleApi.search(params).then(res => {
                    let flag = res.data.success;
                    flag ?this.$message("查询角色,"+res.data.message):this.$message.error("查询角色,"+res.data.message)
                    if(res.data.data){
                        this.roles = res.data.data.list;
                        this.totalNum = res.data.data.total;
                        //防止当前页大于最大页数，序号会发生错乱
                        this.page = res.data.data.page;
                    }
                }).catch(err => {

                    this.$message.error("系统错误" + err)
                })
            },

            handleSizeChange(pageSizes) {
                this.pageSizes = pageSizes;
                this.handleselect()
            },
            handleCurrentChange(page) {
                this.page = page;
                this.handleselect()
            },
            //获取选中行的数据
            handleSelectionChange(val) {
                this.multipleTable = val;               //  this.multipleTable 选中的值
            },
            //日期格式化 yyyy-MM-dd HH:mm:ss
            dateFormat: function (row, column) {
                let date = row[column.property]
                if (date == undefined)
                    return ''
                return moment(date).format("YYYY-MM-DD HH:mm:ss")
            },
            //弹窗 修改用户
            handleEdit(item) {
                this.$refs.editRole.dialogFormVisible = true
                this.$refs.editRole.role = item
            },
            //弹窗 增加用户
            handleadd() {
                this.$refs.addRole.dialogFormVisible = true
            },
            //弹窗 设置权限
            handlePermission(item) {
                this.$refs.setPermission.dialogFormVisible = true
                this.$refs.setPermission.role = item
            },
            // 删除
            handleDelete(item) {
                this.$confirm(
                    `本次操作将删除"${item.roleName}"角色，删除后将不可恢复，您确认删除吗？`, {
                        type: 'warning'
                    }
                ).then(() => {
                    RoleApi.deleteRole(item).then((res) => {
                        this.handleselect();//刷新表格
                        res.data.success ?this.$message("删除角色,"+res.data.message):this.$message.error("删除角色,"+res.data.message)
                    }).catch(err => {
                        this.$message.error("系统错误" + err)
                    })
                })
            },
            //批量删除
            handleDeleteAll() {
                this.$confirm(
                    `本次操作将删除所有选中的角色，删除后账号将不可恢复，您确认删除吗？`, {
                        type: 'warning'
                    }
                ).then(() => {
                    RoleApi.deleteAll(this.multipleTable).then((res) => {
                        this.handleselect();//刷新表格
                        res.data.success ?this.$message("批量删除角色,"+res.data.message):this.$message.error("批量删除角色,"+res.data.message)
                    })
                }).catch(err => {
                    this.$message.error("系统错误" + err)
                })
            }
        }
    }
</script>
<style>
</style>