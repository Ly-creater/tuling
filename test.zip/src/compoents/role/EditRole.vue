<template>
    <div id="editRole">
        <el-dialog title="编辑角色" :modal-append-to-body='false' :visible.sync="dialogFormVisible"  style="width: 1000px;margin-left: 200px"  :center=true>
            <el-form :model="role"  ref="user">
                <el-form-item label="rid:" :label-width="formLabelWidth" prop="rid" size="small" v-if="false">
                    <el-input v-model="role.rid" auto-complete="off" ></el-input>
                </el-form-item>
                <el-form-item label="角色名称:" :label-width="formLabelWidth" prop="name" size="small">
                    <el-input v-model="role.roleName" auto-complete="off"></el-input>
                </el-form-item>
                <el-form-item label="角色编码:" :label-width="formLabelWidth" prop="username" size="small">
                    <el-input v-model="role.roleCode" auto-complete="off" ></el-input>
                </el-form-item>
                <el-form-item label="生效日期:" :label-width="formLabelWidth" prop="password" size="small">
                    <el-date-picker size="small" type="date" placeholder="选择日期" v-model="role.effectiveDate" style="width: 100%"></el-date-picker>
                </el-form-item>
                <el-form-item label="失效日期:" :label-width="formLabelWidth" prop="sex" size="small">
                    <el-date-picker size="small" type="date" placeholder="选择日期" v-model="role.expirationDate" style="width: 100%"></el-date-picker>
                </el-form-item>
                <el-form-item label="状态:" :label-width="formLabelWidth" prop="roleState" size="small">
                    <el-radio v-model="role.roleState" label= "有效">有效</el-radio>
                    <el-radio v-model="role.roleState" label= "无效">无效</el-radio>
                </el-form-item>
                <el-form-item label="备注:" :label-width="formLabelWidth" size="small">
                    <el-input type="textarea" v-model="role.roleInfo" ></el-input>
                </el-form-item>
            </el-form>
            <div slot="footer" class="dialog-footer">
                <el-button @click="dialogFormVisible = false">取 消</el-button>
                <el-button type="primary" @click="submit">提交</el-button>
            </div>
        </el-dialog>
    </div>
</template>


<script>
    import {editRole} from '../../network/role'
    export default {
        name: "EditRole",
        data() {
            return {
                dialogTableVisible: false,
                dialogFormVisible: false,
                role: {},
                formLabelWidth: '120px',

            };
        },
        methods: {
            // 表单提交
            submit() {
                editRole(this.role).then(res => {
                    this.dialogFormVisible = false
                    let flag = res.data.success;
                    this.$parent.handleselect();
                    flag ?this.$message("修改角色,"+res.data.message):this.$message.error("修改角色,"+res.data.message)
                }).catch(err => {
                    this.$message.error("系统错误"+err)
                })
            }
        },
    }
</script>

<style scoped>

</style>