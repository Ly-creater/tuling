<template>
    <div  id="SetPermission">
        <el-dialog title="设置角色权限" :modal-append-to-body='false' :visible.sync="dialogFormVisible" style="width: 1000px;margin-left: 200px"  @open='getCheckIds' :center=true @close='clearIds'>
            <el-card class="box-card">
                <div style="width: 40%">
                    <el-input v-model="role.roleName" :disabled="true" style="width: 300px">
                        <template slot="prepend">角色名称：</template>
                    </el-input>
                    <el-input v-model="role.rid" :disabled="true" v-if="false">
                        <template slot="prepend">角色名称：</template>
                    </el-input>
                </div>
            </el-card>
            <el-card class="box-card">
                <el-tree
                        ref="tree"
                        :data="data2"
                        show-checkbox
                        node-key="mid"
                        :default-checked-keys="this.checkedIds"
                        :props="{label:'menuName'}"
                        :default-expand-all="true"
                        @check-change="handleCheckChange"
                        :check-strictly="checkStrictly">
<!--                    :check-strictly 控制父组件与子组件是否级联操作-->
                </el-tree>
            </el-card>
            <el-card class="box-card">
                <el-button @click="dialogFormVisible = false">取 消</el-button>
                <el-button type="primary" @click="submit">提交</el-button>
            </el-card>
        </el-dialog>
    </div>
</template>

<script>
    import {selectAll} from "../../network/menu";
    import {saveMenu} from "../../network/role";
    // selectRole

    export default {
        name: "SetPermission",
        data() {
            return {
                dialogTableVisible: false,
                dialogFormVisible: false,
                formLabelWidth: '120px',
                role: {},
                menus: [],
                checkedIds: [],
                checkedPermissions: [],
                permissions: [],
                data2: [],
                checkStrictly: false
            };
        },
        methods: {
            submit(){
                saveMenu(this.role).then(res =>{
                    this.dialogFormVisible = false
                    let flag = res.data.success;
                    flag ?this.$message("设置权限"+res.data.message):this.$message.error("设置权限"+res.data.message)
                }).catch(err =>{
                    console.log("设置权限错误",err);
                    this.dialogFormVisible=false
                })
            },
            toTree(list,parId){
                let len = list.length
                function loop(parId){
                    let res = [];
                    for(let i = 0; i < len; i++){
                        let item = list[i]
                        if(item.parentId === parId){
                            item.children = loop(item.mid)
                            res.push(item)
                        }
                    }
                    return res
                }
                return loop(parId)
            },
            //数值去重
            unique(arr){
                return Array.from(new Set(arr))
            },
            //获取所有权限，并动态构成权限树
            allPermission() {
                selectAll().then(res => {
                    let flag = res.data.success;
                    flag ?this.$message("获取所有菜单,"+res.data.message):this.$message.error("获取所有菜单,"+res.data.message)
                    if(res.data.data){
                        this.permissions = res.data.data;
                        this.data2 = this.unique(this.toTree(this.permissions, 0));
                    }
                }).catch(err => {
                    this.$message.error("系统错误,"+err)
                })
            },
            //当树的选中状态发生改变时，触发这个函数
            handleCheckChange () {
                let checkeds= []
                let res = this.$refs.tree.getCheckedNodes()
                res.forEach((item) => {
                    checkeds.push(item)
                })
                this.checkedPermissions=checkeds
                this.role.menus =checkeds
            },
            //树回显 注意这里弹窗中的钩子函数(除了Destroy之类的）都相当于在父组件内定义的钩子函数一样同时执行，所以会在钩子函数中获取不到父组件传来的数据
            //弹窗定义了两个回调函数来完成close open
            getCheckIds(){
                this.checkStrictly =true  //回显数据时不级联
                if(this.role.menus!=null){
                    this.role.menus.forEach((item)=>{
                        this.checkedIds.push(item.mid)
                    })
                    this.$nextTick(() => {
                        this.$refs.tree.setCheckedKeys(this.checkedIds);
                    });
                }else {
                    this.$nextTick(() => {
                        this.$refs.tree.setCheckedKeys([]);
                    });
                }
                setTimeout(()=>{
                    this.checkStrictly = false //选择时级联
                },900)
            },
            clearIds(){
                //在关闭弹窗时，清空this.checkedIds，然后通过this.$refs.tree.setCheckedKeys(this.checkedIds);来改变选中的keys,
                // 防止出现显示不同角色都显示一样
                this.checkedIds = []
            },

        },
        created() {
            this.allPermission()
        }

    }
</script>

<style scoped>

</style>