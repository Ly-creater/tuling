<template>
    <div id="MySlot">
        <el-card class="box-card">
            <span style="color: lightgreen;font-size: large">
                <slot></slot>
            </span>
        </el-card>
    </div>
</template>

<script>
    export default {
        name: "MySlot"
    }
</script>

<style scoped>

</style>