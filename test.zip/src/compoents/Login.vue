<template>
    <div id="login">
        <el-card class="box-card" style="width:35%;margin-left: 430px;margin-top: 60px">

            <div slot="header" class="clearfix">
                <span>登录界面</span>
            </div>
            <el-form ref="form" :model="form" label-width="80px">
                <el-form-item label="用户名:">
                    <el-input v-model="form.username" placeholder="请输入用户名称"></el-input>
                </el-form-item>
                <el-form-item label="密码:">
                    <el-input v-model="form.password" placeholder="请输入密码" type="password"></el-input>
                </el-form-item>

                <el-form-item prop="code" label="验证码:">
                    <el-input type="text" v-model="form.code" placeholder="请输入验证码">
                        <template slot="append">
                            <div  @click="refreshCode">
                                <Identify :identifyCode="identifyCode"></Identify>
                            </div>
                        </template>
                    </el-input>
                </el-form-item>
                <div style="margin-left:-200px;margin-bottom: 10px">
                    <template >
                        自动登录:  <el-checkbox  true-label="true" false-label="false" v-model="form.autoLogin"></el-checkbox>
                    </template>
                </div>
                <el-form-item>
                    <el-button round type="primary"  @click="loginUser" style="width: 30% ;margin-left: -60px">登录</el-button>
                    <el-button round type="primary"  @click="registerUser" style="width: 30% ; margin-left:60px">注册</el-button>
                </el-form-item>
            </el-form>
        </el-card>
        <AddUser ref="addUser"></AddUser>
    </div>
</template>

<script>
    import {login, getCode} from '../network/user'
    import IdentityCode from "./IdentityCode";
    import AddUser from "./user/AddUser";

    export default {
        components: {
            Identify: IdentityCode,
            AddUser
        },
        name: 'login',
        data() {
            return {
                identifyCode: '',//
                form: {
                    autoLogin:false
                },
            }
        },
        methods: {
            refreshCode() {
                this.getIdentityCode();
            },
            getIdentityCode() {
                getCode().then(res => {
                    this.identifyCode = res.data.data;
                })
            },
            registerUser(){
                this.$refs.addUser.dialogFormVisible = true
                this.$refs.addUser.user.state  =  '无效'
                this.$refs.addUser.isVisible = false
                this.$refs.addUser.title = "注册用户"
            },

            loginUser() {
                login(this.form).then(res => {
                        console.log(res)
                        let code = res.data.code
                        if (code === 1000) {
                                this.$message('登录成功');
                        if(this.$route.query.redirect){
                            let redirect=this.$route.query.redirect;
                            this.$router.push(redirect);
                        }else {
                            this.$router.push('/index');
                        }
                            localStorage.setItem("username", res.data.data);
                        } else {
                            this.$message.error(res.data.message);
                        }
                    }
                )
            }
        },
        mounted() {
            // 初始化验证码
            this.identifyCode = ''
            this.getIdentityCode()
        },
    }
</script>


<style>
    .el-card__header {
        background-color: blanchedalmond;
    }
</style>