<template>
    <div id="Top" >
        <el-menu class="el-menu-vertical-demo" mode="horizontal">
            <span class="app-breadcrumb">
                用户权限管理系统<span class="breadBtn">体验版</span>
            </span>
            <span class="el-dropdown-link">
              <img class="avatar" src="../assets/bigUserHeader.png"/>
                欢迎用户<span style="color: blue">{{username}}</span>登陆！
                <el-button type="warning" @click="loginout" size="small">退出</el-button>
            </span>
        </el-menu>
    </div>

</template>

<script>
    export default {
        name: 'Top',
        components: {},
        computed: {},
        data() {
            return {
                username: ''
            }
        },
        methods: {
            loginout() {
                this.$confirm("确定要退出当前用户吗").then(() => {
                    //删除相应的cookie
                    window.$cookies.remove("REMEBERME_COOKIE");
                    window.$cookies.remove("USER_COOKIE");
                    localStorage.clear();
                    this.$router.push('/');
                })
            }
        },
        mounted() {
            this.username=localStorage.getItem("username");
        },
    }
</script>

<style>
    .app-breadcrumb {
        /*display: inline-block;*/
        font-size: 18px;
        line-height: 50px;
        margin-left: 10px;
        color: black;
        float: left;
        /*cursor: text;*/
    }

    .el-dropdown-link {
        font-size: 18px;
        line-height: 50px;
        margin-left: 10px;
        color: black;
        float: right;
    }

    .avatar {
        width: 22px;
        vertical-align: -5px;
    }

    .breadBtn {
        background: #84a9fe;
        font-size: 14px;
        padding: 0 10px;
        display: inline-block;
        height: 30px;
        line-height: 30px;
        border-radius: 10px;
        margin-left: 15px;
    }
    .el-menu-vertical-demo{
        /*background-color: cornflowerblue;*/
    }
</style>
