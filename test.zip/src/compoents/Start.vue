<template>
    <div id="start">
        <Top></Top>
        <Navbar></Navbar>
    </div>
</template>

<script>
    import Top from './Top'
    import Navbar from './Navbar'
    export default {
        name: "Start",
        components: {
            Top,
            Navbar
        }
    }
</script>

<style >
    #start {
        padding: 0;
        margin: 0;
        background: url("../../src/assets/5b8abc339a62b.jpg");
        width: 100%;
        height: 100%;
        position: fixed;
        background-size: 100% 100%;
    }
</style>