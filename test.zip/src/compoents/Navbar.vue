<template>
    <div id="Navbar">
        <el-row class="tac" style="height: 100%">
            <el-col :span="12">
                <h5>系统管理</h5>
                <el-menu default-active="2" class="el-menu-vertical-demo" @open="handleOpen" @close="handleClose">
                    <el-menu-item index="/user" @click="goTo('/user')">
                        <i class="el-icon-printer"></i>
                        <span slot="title">用户管理</span>
                    </el-menu-item>
<!--                    v-if="false"-->
                    <el-menu-item index="/role" @click="goTo('/role')">
                        <i class="el-icon-document"></i>
                        <span slot="title">角色管理</span>
                    </el-menu-item>
                    <el-menu-item index="/menu" @click="goTo('/menu')">
                        <i class="el-icon-setting"></i>
                        <span slot="title">菜单管理</span>
                    </el-menu-item>
                </el-menu>
            </el-col>
            <router-view></router-view>
        </el-row>
    </div>
</template>

<script>
    export default {
        name: 'Navbar',
        data() {
            return {};
        },
        methods: {
            handleOpen(key, keyPath) {
                console.log(key, keyPath);
            },
            handleClose(key, keyPath) {
                console.log(key, keyPath);
            },
            goTo(path) {
                this.$router.push(path)
            }
        }
    };
</script>

<style scoped>
    .el-col-12{
        width: 15%;
    }

    #navbar,.el-row,#app,html,body{
        padding: 0;
        margin: 0;
        height: 100%;
    }
    .el-menu-vertical-demo{
        border-right: none;
        opacity: 30%;
    }
</style>