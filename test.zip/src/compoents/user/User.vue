<template>
    <span style="width: 100%">
          <MySlot><i class="el-icon-printer">用户管理</i></MySlot>
        <!--        搜索框-->
        <el-card class="box-card">
            用户名：<el-input size="small" placeholder="请输入内容" v-model="username" style="width: 10%;"></el-input>
            姓名：<el-input size="small" placeholder="请输入内容" v-model="name" style="width: 10%;"></el-input>
            &nbsp;
            <span>状态：
                <el-select size="small" v-model="state" placeholder="全部" style="width: 7%">
                    <el-option value="">全部</el-option>
                    <el-option value="有效">有效</el-option>
                    <el-option value="无效">无效</el-option>
                </el-select>
            </span>
            <span style="width: 10%;">
                创建时间：由
                <el-date-picker size="small" type="date" placeholder="选择日期" v-model="createDate"
                                style="width: 11%;"></el-date-picker>
                至
                <el-date-picker size="small" type="date" placeholder="选择日期" v-model="updateDate"
                                style="width: 11%;"></el-date-picker>
            </span>
            &nbsp;
            <span>
                <el-button size="mini" type="primary" @click="handleselect">查询</el-button>
                <el-button size="mini" type="success" @click="handleadd">新增</el-button>
                <el-button size="mini" type="danger" @click="handleDeleteAll">删除</el-button>
            </span>
        </el-card>
        <!--        表格-->
        <el-card class="box-card">
            <el-table ref="multipleTable"
                      stripe
                      height="410"
                      @selection-change="handleSelectionChange" :data="userList" tooltip-effect="dark"
                      style="width: 100%" float="left">
                <el-table-column type="selection" width="30" align="center"></el-table-column>
                <el-table-column label="序号" width="50" align="center">
                    <template slot-scope="scope">
                        <span>{{(page - 1) * pageSizes + scope.$index + 1}}</span>
                    </template>
                </el-table-column>
                <el-table-column prop="username" label="用户名" width="70" align="center"></el-table-column>
                <el-table-column prop="name" label="姓名" width="60" align="center"></el-table-column>
                <el-table-column prop="sex" label="性别" width="50" align="center"></el-table-column>
                <el-table-column prop="mobile" label="联系电话" width="110" align="center"></el-table-column>
                <el-table-column prop="email" label="邮箱" width="110" align="center"></el-table-column>
                <el-table-column prop="createDate" label="修建时间" width="100" :formatter="dateFormat"
                             align="center"></el-table-column>
                <el-table-column prop="updateDate" label="最后修建时间" width="105" :formatter="dateFormat"
                             align="center"></el-table-column>
                <el-table-column prop="state" label="状态" width="50" align="center"></el-table-column>
                <el-table-column label="操作" align="center">
                    <template slot-scope="scope"><!--  slot-scope="scope" 这里取到当前单元格  -->
                        <el-button
                            size="mini"
                            type="primary"
                            @click="handleEdit(scope.row)">修改</el-button>
                        <el-button
                            size="mini"
                            type="danger"
                            @click="handleDelete(scope.row)">删除</el-button>
                        <el-button
                            size="mini"
                            type="info"
                            @click="handleWuxiao(scope.row)">无效</el-button>
                        <el-button
                            size="mini"
                            type="warning"
                            @click="handleRole(scope.row)">设置角色</el-button>
                    </template>
                </el-table-column>
            </el-table>
            <!--        分页组件-->
            <el-pagination
                @size-change="handleSizeChange"
                @current-change="handleCurrentChange"
                :current-page="page"
                :page-sizes="[5, 10, 15, 20]"
                :page-size="100"
                layout="total, sizes, prev, pager, next, jumper"
                :total="totalNum">
            </el-pagination>
        </el-card>

        <AddUser ref="addUser"></AddUser>
        <EditUser ref="editUser"></EditUser>
        <SetRole ref="setRole"></SetRole>
    </span>

</template>

<script>
    import moment from 'moment';
    import * as UserApi from '../../network/user'
    import AddUser from "./AddUser";
    import EditUser from "./EditUser";
    import SetRole from "./SetRole";
    import MySlot from "../MySlot";

    export default {
        name: 'user',
        components: {
            AddUser,
            EditUser,
            SetRole,
            MySlot
        },
        data() {
            return {
                username: '',
                name: '',
                state: '',
                createDate: '',
                updateDate: '',
                user: {},
                multipleTable: [],//选中行的数据
                userList: [],
                pageSizes: 5,  //每页显示的数量
                totalNum: 0,  //总数量
                page: 1      //当前页
            }
        },
        created() {
            this.handleselect()
        },
        methods: {
            //查询用户和搜索用户
            handleselect() {
                let params = {
                    username: this.username,
                    name: this.name,
                    state: this.state,
                    createDate: this.createDate,
                    updateDate: this.updateDate,
                    pageSizes: this.pageSizes,
                    page: this.page,
                    // enablePage: true
                };
                UserApi.search(params).then(res => {
                    let flag = res.data.success;
                    flag ?this.$message("查询用户,"+res.data.message):this.$message.error("查询用户,"+res.data.message)
                    if(res.data.data){
                        this.userList = res.data.data.list;
                        this.totalNum = res.data.data.total;
                        //防止当前页大于最大页数，序号会发生错乱
                        this.page = res.data.data.page;
                    }
                }).catch(err => {
                    this.$message.error("系统错误" + err)
                })
            },

            handleSizeChange(pageSizes) {
                this.pageSizes = pageSizes;
                this.handleselect()
            },
            handleCurrentChange(page) {
                this.page = page;
                this.handleselect()
            },
            //获取选中行的数据
            handleSelectionChange(val) {
                this.multipleTable = val;               //  this.multipleTable 选中的值
                console.log(val);
            },
            //日期格式化 yyyy-MM-dd HH:mm:ss
            dateFormat: function (row, column) {
                let date = row[column.property]
                if (date == undefined)
                    return ''
                return moment(date).format("YYYY-MM-DD HH:mm:ss")
            },
            //弹窗 修改用户
            handleEdit(item) {
                console.log("2323",this.$refs);
                this.$refs.editUser.dialogFormVisible = true
                this.$refs.editUser.user = item
            },
            //弹窗 增加用户
            handleadd() {
                this.$refs.addUser.dialogFormVisible = true
            },
            //弹窗 设置角色
            handleRole(item) {
                this.$refs.setRole.dialogFormVisible = true
                this.$refs.setRole.user = item
            },
            // 删除
            handleDelete(item) {
                this.$confirm(
                    `本次操作将删除${item.username}删除后账号将不可恢复，您确认删除吗？`, {
                        type: 'warning'
                    }
                ).then(() => {
                    UserApi.deleteUser(item).then((res) => {
                        this.handleselect();//刷新表格
                        res.data.success ?this.$message("删除用户,"+res.data.message):this.$message.error("删除用户,"+res.data.message)
                    }).catch(err => {
                        this.$message.error("系统错误" + err)
                    })
                })
            },
            //批量删除
            handleDeleteAll() {
                this.$confirm(
                    `本次操作将删除所有选中的用户，删除后账号将不可恢复，您确认删除吗？`, {
                        type: 'warning'
                    }
                ).then(() => {
                    UserApi.deleteAll(this.multipleTable).then((res) => {
                        this.handleselect();//刷新表格
                        res.data.success ?this.$message("批量删除,"+res.data.message):this.$message.error("批量删除,"+res.data.message)
                    })
                }).catch(err => {
                    this.$message.error("系统错误" + err)
                })
            },
            //设置无效
            handleWuxiao(item) {
                this.$confirm(
                    `本次操作将${item.username}设置为无效状态，您确认进行吗？`, {
                        type: 'warning'
                    }
                ).then(() => {
                    UserApi.updateState(item).then(res => {
                        this.handleselect();//刷新表格
                        res.data.success ?this.$message("设置为无效,"+res.data.message):this.$message.error("设置为无效,"+res.data.message)
                    }).catch(err => {
                        this.$message.error("修改状态失败" + err)
                    })
                })
            }
        }
    }
</script>
<style>
</style>