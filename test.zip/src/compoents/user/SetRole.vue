<template>
    <div>
        <el-dialog title="设置角色" :modal-append-to-body='false' :visible.sync="dialogFormVisible" style="width: 1550px" @open="getCheckedRole" @close="clearIds">
            <el-card class="box-card">
                <div style="width: 40%">
                    <el-input v-model="user.username" :disabled="true">
                        <template slot="prepend">用户名：</template>
                    </el-input>
                </div>
            </el-card>
            <!--            <div style="float:left">用户名：<input type="text"></div>-->
            <el-card class="box-card">
                <div>
                    <el-card class="box-card">
                        <el-table ref="tabled"
                                  stripe
                                  height="290"
                                  @selection-change="handleSelectionChange" :data="roles" tooltip-effect="dark"
                                  style="width: 100%" float="left" :row-key="getRowKeys" >
                            <el-table-column type="selection" width="40" align="center"
                                             :reserve-selection="true"></el-table-column>
                            <el-table-column label="序号" width="80" align="center">
                                <template slot-scope="scope">
                                    <span>{{(page-1) * pageSizes + scope.$index + 1}}</span>
                                </template>
                            </el-table-column>
                            <el-table-column prop="roleName" label="角色名称" width="120" align="center"></el-table-column>
                            <el-table-column prop="roleCode" label="角色编码" width="120" align="center"></el-table-column>
                            <el-table-column prop="effectiveDate" label="生效日期" width="100"
                                             align="center"></el-table-column>
                            <el-table-column prop="expirationDate" label="失效日期" width="100"
                                             align="center"></el-table-column>
                            <el-table-column prop="roleState" label="状态" width="80" align="center"></el-table-column>
                        </el-table>
                        <!--        分页组件-->
                        <el-pagination
                                @size-change="handleSizeChange"
                                @current-change="handleCurrentChange"
                                :current-page="page"
                                :page-sizes="[5, 10, 15, 20]"
                                :page-size="100"
                                layout="total, sizes, prev, pager, next, jumper"
                                :total="totalNum">
                        </el-pagination>

                    </el-card>
                    <el-card class="box-card">
                        <el-button @click="dialogFormVisible = false">取 消</el-button>
                        <el-button type="primary" @click="formBtn">提交</el-button>
                    </el-card>
                </div>
            </el-card>
        </el-dialog>
    </div>
</template>

<script>
    import {search} from "../../network/role";
    import {saveRole} from "../../network/user";

    export default {
        name: "SetRole",
        data() {
            return {
                user: {},
                roles: [],
                role: {},
                formLabelWidth: '120px',
                multipleTable: [],//选中行的数据
                pageSizes: 5,  //每页显示的数量
                totalNum: 0,  //总数量
                page: 1,      //当前页
                dialogFormVisible: false
            }
        },
        methods: {
            handleselect() {
                let params = {
                    role: this.role,
                    pageSizes: this.pageSizes,
                    page: this.page,
                };
                search(params).then(res => {
                    let flag = res.data.success;
                    flag ? this.$message("查询角色,"+res.data.message) : this.$message.error("查询角色,"+res.data.message)
                    if(res.data.data){
                        this.roles = res.data.data.list;
                        this.totalNum = res.data.data.total;
                        //防止当前页大于最大页数，序号会发生错乱
                        this.page = res.data.data.page;
                    }
                }).catch(err => {
                    this.$message.error("系统错误" + err)
                })
            },
            handleSizeChange(pageSizes) {
                this.pageSizes = pageSizes;
                this.handleselect()
            },
            handleCurrentChange(page) {
                this.page = page;
                this.handleselect()
            },
            getRowKeys(row){
                return row.id
            },
            // 表单提交
            formBtn() {
                saveRole(this.user)
                    .then((res) => {
                        let flag = res.data.success;
                        if (flag) {
                            this.$parent.handleselect();
                        }
                        flag ? this.$message("设置角色,"+res.data.message) : this.$message.error("设置角色,"+res.data.message)
                    }).catch((err) => {
                    this.$message.error(err)
                })
                this.dialogFormVisible = false
            },
            //获取选中行的数据
            handleSelectionChange(val) {
                this.multipleTable=val
                this.user.roles = val;               //  this.multipleTable 选中的值
            },
            //回显shuj
            getCheckedRole(){
                this.$nextTick(() => {
                    if(this.user.roles!=null){
                        this.user.roles.forEach((item)=>{
                            this.roles.forEach((role1)=>{
                                if(item.rid===role1.rid){
                                    this.$refs.tabled.toggleRowSelection(role1,true)
                                }
                            })
                        })
                    }
                })
            },
            clearIds(){
                this.$nextTick(() => {
                    this.roles.forEach((role1)=> {
                        this.$refs.tabled.toggleRowSelection(role1,false)
                    })
                })
            }

        },
        created() {
            this.handleselect()
        },
    }
</script>

<style scoped>

</style>