<template>
    <div id="AddUser">
        <el-dialog :title="title" :modal-append-to-body='false' :visible.sync="dialogFormVisible"  style="width: 1000px;margin-left: 200px" :center=true>
            <el-form :model="user" ref="user">
                <el-form-item label="用户名:" :label-width="formLabelWidth" prop="username" size="small">
                    <el-input v-model="user.username" auto-complete="off" ></el-input>
                </el-form-item>
                <el-form-item label="姓名:" :label-width="formLabelWidth" prop="name" size="small">
                    <el-input v-model="user.name" auto-complete="off"></el-input>
                </el-form-item>
                <el-form-item label="密码:" :label-width="formLabelWidth" prop="password" size="small">
                    <el-input v-model="user.password" auto-complete="off" type="password"></el-input>
                </el-form-item>
                <el-form-item label="性别:" :label-width="formLabelWidth" prop="sex" size="small">
                    <el-select v-model="user.sex" placeholder="请选择">
                        <el-option value="男">男</el-option>
                        <el-option value="女">女</el-option>
                    </el-select>
                </el-form-item>
                <el-form-item label="联系电话:" :label-width="formLabelWidth" prop="mobile" size="small">
                    <el-input v-model="user.mobile" auto-complete="off" ></el-input>
                </el-form-item>
                <el-form-item label="邮箱:" :label-width="formLabelWidth" prop="email" size="small">
                    <el-input v-model="user.email" auto-complete="off" ></el-input>
                </el-form-item>
                <el-form-item label="状态:" :label-width="formLabelWidth" prop="state" size="small" v-if="isVisible">
                    <el-radio v-model="user.state" label= "有效">有效</el-radio>
                    <el-radio v-model="user.state" label= "无效">无效</el-radio>
                </el-form-item>
                <el-form-item label="备注:" :label-width="formLabelWidth" size="small">
                    <el-input type="textarea" v-model="user.info" ></el-input>
                </el-form-item>
            </el-form>
            <div slot="footer" class="dialog-footer">
                <el-button @click="dialogFormVisible = false">取 消</el-button>
                <el-button type="primary" @click="formBtn">提交</el-button>
            </div>
        </el-dialog>
    </div>
</template>

<script>
    import {addUser} from '../../network/user'
    export default {
        name: "AddUser",
        data() {
            return {
                dialogTableVisible: false,
                dialogFormVisible: false,
                user: {
                },
                isVisible: true,
                formLabelWidth: '120px',
                title: '新增用户'

            };
        },
        methods:{
        // 表单提交
        formBtn() {
            addUser(this.user).then(res =>{
                this.dialogFormVisible = false
                let flag = res.data.success;
                console.log(this.$route.path);
                console.log(this.$route.path === '/');
                if(this.$route.path==='/'){
                    flag ?this.$message("注册用户,"+res.data.message):this.$message.error("注册用户,"+res.data.message)
                }else{
                    this.$parent.handleselect();
                    flag ?this.$message("增加用户,"+res.data.message):this.$message.error("增加用户,"+res.data.message)
                }
            }).catch(err=>{
                this.$message.error("系统错误"+err)
            })
        }
    },
    }
</script>

<style scoped>

</style>