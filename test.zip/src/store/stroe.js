import vue from 'vue'
import Vuex from 'vuex'

vue.use(Vuex)

const store = new Vuex.Store({
    state: {
        username: ''
    },
    mutations:{
        getUsername(state,data){
            this.state.username=data
        }

    }
})
export default store