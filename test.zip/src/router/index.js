import Vue from 'vue'
// import {Message} from 'element-ui'
import {MessageBox} from 'element-ui'
import Router from 'vue-router'
import Index from '../compoents/Index'
import Menu from '../compoents/menu/MenuManager'
import User from '../compoents/user/User'
import Role from '../compoents/role/Role'
import Login from '../compoents/Login'
import Start from '../compoents/Start'

Vue.use(Router)


export const constantRouterMap = [
    {
        path: '/',
        name: 'login',
        component: Login,
        meta: {
            requireAuth:false
        },
    },
    {
        path: '/index',
        name: 'start',
        component: Start,
        meta: {
            requireAuth:true
        },
        children: [
            {
                path: '/menu',
                name: 'menu',
                component: Menu
            },
            {
                path: '/index',
                name: 'index',
                component: Index
            },
            {
                path: '/user',
                name: 'user',
                component: User,
                hidden: true
            },
            {
                path: '/role',
                name: 'role',
                component: Role
            }
        ]
    }
]

let router = new Router({
    mode: 'history',
    routes: constantRouterMap
})
// 路由守卫
router.beforeEach((to, from, next) => {
    console.log(to.path);
    if(to.path==='/' && window.$cookies.get("REMEBERME_COOKIE")){
        next('/index')
    }else if (to.matched.some(record => record.meta.requireAuth)){  // 判断该路由是否需要登录权限
        if (window.$cookies.get("USER_COOKIE")) {  // 判断当前的token是否存在 ； 登录存入的token
            next();
        } else {
            MessageBox.confirm('你还没有权限访问，请登录后在访问', '提示', {
                confirmButtonText: '确定',
                cancelButtonText: '取消',
                type: 'warning'
            }).then(() => {
                next({
                    path: '/',
                    query: {redirect: to.fullPath}  // 将跳转的路由path作为参数，登录成功后跳转到该路由
                })
            }).catch(() => {
                next({
                    path: '/'
                })
            });
        }
    } else {
        next();
    }
});

export default router