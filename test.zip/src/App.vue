<template>
    <div id="app" >
        <!--      当做是一个容器，它渲染的组件是你使用 vue-router 指定的-->
        <router-view></router-view>
    </div>
</template>

<script>
    export default {
        name: 'App',
        components: {},
        data() {
            return {
            }
        },
    }
</script>

<style>

    #app,html,body{
        font-family: Avenir, Helvetica, Arial, sans-serif;
        /*抗锯齿*/
        -webkit-font-smoothing: antialiased;
        -moz-osx-font-smoothing: grayscale;
        text-align: center;
        color: #2c3e50;
        padding: 0;
        margin: 0;
        /*5b8f4c54396f4.jpg*/
        background: url("../src/assets/5b8abc339a62b.jpg");
        width: 100%;
        height: 100%;
        position: fixed;
        background-size: 100% 100%;
    }
</style>
