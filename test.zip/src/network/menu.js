import {createAPI} from "./request"

//1.角色api
export const search = data => createAPI('/menu/search', 'post', data)
export const deleteAll = data => createAPI('/menu', 'delete', data)
export const selectAll = data => createAPI('/menu/all', 'get', data)
export const deleteMenu = data => createAPI(`/menu/${data.mid}`, 'delete', data)
export const addMenu = data => createAPI('/menu', 'post', data)
export const editMenu = data => createAPI('/menu', 'put', data)


