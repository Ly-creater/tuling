import {createAPI} from "./request"

//1.角色api
export const search = data => createAPI('/role/search', 'post', data)
export const deleteAll = data => createAPI('/role', 'delete', data)
export const deleteRole = data => createAPI(`/role/${data.rid}`, 'delete', data)
export const selectRole = data => createAPI(`/role/${data.rid}`, 'put', data)
export const addRole = data => createAPI('/role', 'post', data)
export const editRole = data => createAPI('/role', 'put', data)
export const saveMenu = data => createAPI('/role/menu', 'post', data)

