import axios from 'axios'
axios.defaults.withCredentials=true

const instance = axios.create({
  baseURL: 'http://localhost:8081',
  timeout: 5000,
  headers: {
      "Content-Type": "application/json",
  }
});
export const createAPI = (url, method, data) => {
    let config = {}
    if (method === 'get') {
        config.params =data
    } else {
        config.data = data
    }
    return instance({
        url,
        method,
        ...config
    })
}
// instance.interceptors.request.use(config =>{
//   config.headers['Authorization'] = 'Bearer '+window.$cookies.get('SIE_COOKIE')
//   return config
// })
// instance.interceptors.response.use(
//     response => {
//       console.log(response)
//       //当返回信息为未登录或者登录失效的时候重定向为登录页面
//       if (response.data.code === 502 || response.data.message === '您还未登录') {
//         this.$router.push('/');
//       }
//       return response;
//     },
//     error => {
//       return Promise.reject(error)
//     }
// )

