import {createAPI} from "./request"

// //1.用户api
export const login = data => createAPI('/user/login', 'post', data)
export const search = data => createAPI('/user/search', 'post', data)
export const deleteAll = data => createAPI('/user', 'delete', data)
export const deleteUser = data => createAPI(`/user/${data.id}`, 'delete', data)
// 保存
export const addUser = data => createAPI('/user', 'post', data)
export const editUser = data => createAPI('/user', 'put', data)
export const updateState = data => createAPI(`/user/${data.id}`, 'put', data)
export const saveRole = data => createAPI('/user/role', 'post', data)
export const getCode = data => createAPI('/user/code', 'get', data)


