package com.example.demo.config;

//@Configuration
public class ShiroConfiguration {
    //@Bean
    //MyRealm myRealm() {
    //    MyRealm myRealm = new MyRealm();
    //    myRealm.setCredentialsMatcher(getHashedCredentialsMatcher());
    //    return new MyRealm();
    //}
    //@Bean
    //DefaultWebSecurityManager securityManager() {
    //    DefaultWebSecurityManager manager = new DefaultWebSecurityManager();
    //    manager.setRealm(myRealm());
    //    manager.setRememberMeManager(rememberMeManager());
    //    return manager;
    //}
    //@Bean
    //ShiroFilterChainDefinition shiroFilterChainDefinition() {
    //    DefaultShiroFilterChainDefinition definition = new DefaultShiroFilterChainDefinition();
    //    /*
    //     *   常见的过滤器：
    //     *       anon:无需认证（登录）可以访问
    //     *       authc:必须认证才可以访问
    //     *       user:如果使用rememberMe的功能可以访问
    //     *       perms:该资源必须得到资源权限才可以访问
    //     *       roles:该资源必须得到角色权限才可以访问
    //     * */
    //    definition.addPathDefinition("/user/login", "anon");
    //    definition.addPathDefinition("/user/code", "anon");
    //    return definition;
    //}
    ////开启shiro注解支持
    //@Bean
    //public AuthorizationAttributeSourceAdvisor authorizationAttributeSourceAdvisor(SecurityManager securityManager) {
    //    AuthorizationAttributeSourceAdvisor advisor = new AuthorizationAttributeSourceAdvisor()                 ;
    //    advisor.setSecurityManager(securityManager);
    //    return advisor;
    //}
    //@Bean
    //public HashedCredentialsMatcher getHashedCredentialsMatcher(){
    //    HashedCredentialsMatcher matcher = new HashedCredentialsMatcher();
    //    //设置加密次数
    //    matcher.setHashIterations(3);
    //    //设置加密方式
    //    matcher.setHashAlgorithmName("MD5");
    //    return matcher;
    //}
    //
    //@Bean
    //public static DefaultAdvisorAutoProxyCreator getDefaultAdvisorAutoProxyCreator() {
    //    DefaultAdvisorAutoProxyCreator defaultAdvisorAutoProxyCreator = new DefaultAdvisorAutoProxyCreator();
    //    defaultAdvisorAutoProxyCreator.setUsePrefix(true);
    //    return defaultAdvisorAutoProxyCreator;
    //}
    //@Bean
    //public static RememberMeManager rememberMeManager(){
    //    CookieRememberMeManager cookieRememberMeManager = new CookieRememberMeManager();
    //    SimpleCookie cookie = new SimpleCookie("rememberMe");
    //    cookie.setMaxAge(30*60);
    //    cookie.setSecure(false);
    //    cookie.setHttpOnly(false);
    //    cookieRememberMeManager.setCookie(cookie);
    //    return cookieRememberMeManager;
    //}
}
