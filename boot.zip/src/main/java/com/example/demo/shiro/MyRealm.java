//package com.example.demo.shiro;
//
//import com.example.demo.common.ResultCode;
//import com.example.demo.common.exception.CommonException;
//import com.example.demo.domain.Menu;
//import com.example.demo.domain.Role;
//import com.example.demo.domain.User;
//import com.example.demo.mapper.UserMapper;
//import com.example.demo.service.UserService;
//import lombok.SneakyThrows;
//import org.apache.shiro.authc.*;
//import org.apache.shiro.authz.AuthorizationInfo;
//import org.apache.shiro.authz.SimpleAuthorizationInfo;
//import org.apache.shiro.realm.AuthorizingRealm;
//import org.apache.shiro.subject.PrincipalCollection;
//import org.apache.shiro.util.SimpleByteSource;
//import org.springframework.beans.factory.annotation.Autowired;
//
//import java.util.HashSet;
//import java.util.Set;
//
///**
// * @BelongsProject: sie - 副本
// * @BelongsPackage: com.example.demo.shrio
// * @Author: jkl
// * @CreateTime: 2020
// * @Description:
// */
//public class MyRealm extends AuthorizingRealm {
//    public void setName(){
//        super.setName("myRealm");
//    }
//    @Autowired
//    private UserService userService;
//    @Autowired
//    private UserMapper userMapper;
//
//    /**
//     * 在访问需要权限访问的资源时，会调用此方法授权
//     * @param principalCollection
//     * @return
//     */
//    @Override
//    protected AuthorizationInfo doGetAuthorizationInfo(PrincipalCollection principalCollection) {
//        //获取已认证用户的安全数据
//        User user =(User) principalCollection.getPrimaryPrincipal();
//        //构建返回数据
//        SimpleAuthorizationInfo info = new SimpleAuthorizationInfo();
//
//        Set<String> permissionSet = new HashSet<String>();
//        Set<String> roleSet = new HashSet<String>();
//        //获取用户的所有拥有的角色和权限
//        User user2 = userMapper.selectAllTable(user.getId());
//        if(user2!=null){
//            for(Role role:user2.getRoles()){
//                //构建角色名称集合
//                roleSet.add(role.getRoleName());
//            }
//            for(Menu menu:user2.getMenus()){
//                //构建菜单名称集合
//                permissionSet.add(menu.getCharacteristic());
//            }
//        }
//        info.setRoles(roleSet);
//        info.setStringPermissions(permissionSet);
//        return info;
//    }
//
//    /**
//     *调用subject.login方法时会调用此认证方法
//     * @param authenticationToken
//     * @return
//     * @throws AuthenticationException
//     */
//
//    @SneakyThrows
//    @Override
//    protected AuthenticationInfo doGetAuthenticationInfo(AuthenticationToken authenticationToken) throws AuthenticationException {
//        //获取UsernamePasswordToken对象，对用户名和密码进行简单的封装
//    UsernamePasswordToken upToken = (UsernamePasswordToken) authenticationToken;
//        //获取用户名密码
//        String username = upToken.getUsername();
//        //密码以char数组的方式保存
//        String password = new String(upToken.getPassword());
//        //根据用户名和密码查询用户
//        User user = userService.selectByUP(username, password);
//        if (user != null) {
//            //对用户一些信息封装
//            return new SimpleAuthenticationInfo(user, password, new SimpleByteSource("sielocalhost"),getName());
//        } else {
//            //抛出用户名或密码错误异常
//            throw new CommonException(ResultCode.USERNAMEPASSWORDERROR);
//        }
//    }
//}
