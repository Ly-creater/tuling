package com.example.demo.utils;

import com.example.demo.common.ResultCode;
import com.example.demo.common.exception.CommonException;
import com.example.demo.service.UserService;
import io.jsonwebtoken.Claims;
import io.jsonwebtoken.Jwts;
import io.jsonwebtoken.SignatureAlgorithm;
import lombok.Getter;
import lombok.Setter;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.stereotype.Component;

import java.util.Date;

@Getter
@Setter
@ConfigurationProperties(prefix = "jwt.config")
@Component
public class JwtUtils {
    //签名私钥
    private String key;
    //签名的失效时间
    private Long ttl;
    @Autowired
    private UserService userService;

    /**
     * 设置认证token
     *      id:登录用户id
     *      subject：登录用户名
     *
     */
    public String generateToken(Integer id, String username){
        //1.设置失效时间

        long now = System.currentTimeMillis();//当前毫秒
        long exp = now + ttl;
        return Jwts.builder()
                .claim("id", id)
                .claim("username", username)
                .setExpiration(new Date(exp))
                .signWith(SignatureAlgorithm.HS256, key)
                .compact();
    }
    public Claims parseToken(String token) throws CommonException {
        try{
            return Jwts.parser().setSigningKey(key).parseClaimsJws(token).getBody();
        }catch (Exception e){
            throw new CommonException(ResultCode.UNAUTHENTICATED);
        }
    }



}
