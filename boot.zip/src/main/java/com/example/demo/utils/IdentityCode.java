package com.example.demo.utils;

/**
 * @BelongsProject: sie - 副本
 * @BelongsPackage: com.example.demo.utils
 * @Author: jkl
 * @CreateTime: 2020
 * @Description:
 */

/**
 * 生成验证码
 */
public class IdentityCode {
    //public static String IDENTITY_CODES= "1234567890abcdefjhijklinopqrsduvwxyz";
    public static String IDENTITY_CODES= "1234567890";

    public static String getCode(){
        StringBuilder stringBuilder = new StringBuilder();
        char[] identifyCode;
        int i;
        char[] chars = IDENTITY_CODES.toCharArray();
        for(i=0;i<4;i++){
            stringBuilder.append(chars[getRandomNum(0,chars.length)]);
        }
        return stringBuilder.toString();
    }
    public static int getRandomNum(int min,int max){
        return (int)Math.floor(Math.random()*(max-min)+min);
    }


}
