package com.example.demo.utils;

import org.springframework.stereotype.Component;

import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * @BelongsProject: sie
 * @BelongsPackage: com.example.demo.utils
 * @Author: jkl
 * @CreateTime: 2020
 * @Description:
 */
@Component
public class CookieUtils {
    /**
     * 创建和配置cookie
     * @param cookieName
     * @param value
     * @return
     */
    public void createCookie(String cookieName, String value, HttpServletResponse response){
        //1.创建Cookie对象
        Cookie cookie = new Cookie(cookieName, value);
        cookie.setPath("/");
        ////2.设置该cookie的最大有效期
        cookie.setMaxAge(1800);
        cookie.setSecure(false);
        cookie.setDomain("localhost");
        cookie.setHttpOnly(false);
        response.addCookie(cookie);

    }
    /**
     * 获取某个cookie的值
     * @param request
     * @param cookieName
     * @return
     */
    public  String getCookieValue(HttpServletRequest request, String cookieName){
        //Cookie的默认有效期是一次会话中。
        Cookie[] cookies = request.getCookies();
        String value = null;
        if(cookies != null){
            for (Cookie cookie : cookies) {
                //遍历出每一个cookie对象，咱们怎么去判断该cookie是否是我们想要的那个呢?
                //通过cookie的name进行判断
                String name = cookie.getName();
                if (name.equals(cookieName)) {
                    //获取cookie的value
                    value = cookie.getValue();
                }
            }
        }
        return value;
    }
}