package com.example.demo.domain;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.ToString;

import java.io.Serializable;

/**
 * @BelongsProject: sie - 副本
 * @BelongsPackage: com.example.demo.domain
 * @Author: jkl
 * @CreateTime: 2020
 * @Description:
 */
@Data
@NoArgsConstructor
@AllArgsConstructor
@ToString
public class Menu implements Serializable {

    private int mid;  //菜单id
    private String menuName;//菜单名称
    private String parentMenu;//父菜单名称
    private String menuType; //目录，菜单，功能
    private String characteristic;//菜单标识
    private String address;//菜单地址
    private int orderNum; //菜单序号
    private Boolean menuState;//菜单状态
    private String menuInfo;//菜单信息备注
    private Boolean menuVisible;//菜单是否删除
    private int parentId; //父菜单id
}
