package com.example.demo.domain;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.ToString;

import java.io.Serializable;
import java.util.Set;

/**
 * @BelongsProject: sie - 副本
 * @BelongsPackage: com.example.demo.domain
 * @Author: jkl
 * @CreateTime: 2020
 * @Description:
 */
@Data
@NoArgsConstructor
@AllArgsConstructor
@ToString
public class Role implements Serializable {
    private int rid;//角色id
    private String roleName;//角色名称
    private String roleCode;//角色编码
    private Boolean roleState;//角色状态
    private String roleInfo;//角色信息备注
    private Boolean roleVisible; //是否删除
    private Set<Menu> menus;
}
