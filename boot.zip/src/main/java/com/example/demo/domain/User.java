package com.example.demo.domain;


import com.fasterxml.jackson.annotation.JsonFormat;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.ToString;

import java.io.Serializable;
import java.util.Date;
import java.util.List;
import java.util.Set;

/**
 * @BelongsProject: sie
 * @BelongsPackage: com.example.demo.domain
 * @Author: jkl
 * @CreateTime: 2020
 * @Description:
 */
@Data
@AllArgsConstructor
@NoArgsConstructor
@ToString
public class User implements Serializable {
    private Integer id;     //用户id
    private String username;//用户名
    private String password;//密码
    private String name;   //姓名
    private String sex; //性别
    private String mobile;//手机号
    private String email;//邮箱
    @JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss",timezone="GMT+8")
    private Date createDate;//创建时间
    @JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss",timezone="GMT+8")
    private Date updateDate;//最新更新时间
    private Boolean state;//状态
    private String info;//备注信息
    private Boolean isVisible;//是否删除
    private List<Role> roles;
    private Set<Menu> menus;

}
