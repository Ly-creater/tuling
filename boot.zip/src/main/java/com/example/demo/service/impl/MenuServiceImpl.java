package com.example.demo.service.impl;

import com.example.demo.common.ResultCode;
import com.example.demo.common.exception.CommonException;
import com.example.demo.domain.Menu;
import com.example.demo.mapper.MenuMapper;
import com.example.demo.service.MenuService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;

/**
 * @BelongsProject: sie - 副本
 * @BelongsPackage: com.example.demo.service
 * @Author: jkl
 * @CreateTime: 2020
 * @Description:
 */
@Service
@Transactional
public class MenuServiceImpl implements MenuService {
    @Autowired
    private MenuMapper menuMapper;


    @Override
    public void addMenu(Menu menu) throws CommonException {
        //获取父菜单名称
        String parentName = menu.getParentMenu();
        //获取菜单名称
        String menuName = menu.getMenuName();
        //根据菜单名称查询菜单，保证菜单名称唯一
        Menu menu2 = menuMapper.selectByName(menuName);
        if(menu2!=null){
            //菜单名称存在
            throw new CommonException(ResultCode.MENUNAMEEXIST);
        }else{
            if(parentName!=null){
                //根据父菜单名称查找菜单
                Menu menu1 = menuMapper.selectByName(parentName);
                if(menu1!=null){
                    menu.setParentId(menu1.getMid());
                }else {
                    //父菜单名称不存在
                    throw new CommonException(ResultCode.MENUNAEMNOTEXIST);
                }
            }
        }
        menuMapper.insert(menu);
    }

    /**
     * 根据id删除菜单
     * @param id
     */
    @Override
    public void deleteMenu(Integer id) {
        menuMapper.delete(id);
    }

    @Override
    public void updateMenu(Menu menu) throws CommonException {
        //获取父菜单名称
        String parentName = menu.getParentMenu();
        //获取菜单名称
        String menuName = menu.getMenuName();
        //根据菜单名称查询菜单，保证菜单名称唯一
        Menu menu2 = menuMapper.selectByName(menuName);
        if(menu2!=null){
            if(menu2.getMid()!=menu.getMid()){
                throw new CommonException(ResultCode.MENUNAMEEXIST);
            }
        }else {
            if (parentName != null) {
                Menu menu1 = menuMapper.selectByName(parentName);
                if (menu1 != null) {
                    menu.setParentId(menu1.getMid());
                } else {
                    //父菜单名称不存在
                    throw new CommonException(ResultCode.MENUNAEMNOTEXIST);
                }
            }
        }
        menuMapper.updateMenu(menu);
    }

    /**
     * 根据id查询菜单
     * @param id
     * @return
     */
    @Override
    public Menu selectById(Integer id) {
        return menuMapper.selectById(id);
    }

    /**
     * 根据条件查询菜单
     * @param menu
     * @return
     */
    @Override
    public List<Menu> searchMenu(Menu menu) {
        return menuMapper.selectByMenu(menu);
    }
    //批量删除菜单
    @Override
    public void deleteAll(List<Menu> list) {
        menuMapper.deleteByIds(list);
    }

    @Override
    public List<Menu> selectAll() {
        return menuMapper.selectAll();
    }
}
