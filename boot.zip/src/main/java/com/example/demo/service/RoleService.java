package com.example.demo.service;

import com.example.demo.common.exception.CommonException;
import com.example.demo.domain.Role;
import com.example.demo.vo.RoleSearchVo;

import java.util.List;

/**
 * @BelongsProject: sie - 副本
 * @BelongsPackage: com.example.demo.service.impl
 * @Author: jkl
 * @CreateTime: 2020
 * @Description:
 */

public interface RoleService {
    void addRole(Role role) throws CommonException;
    void deleteRole(Integer id);
    void updateRole(Role role) throws CommonException;

    List<Role> searchRole(RoleSearchVo roleSearchVo);
    void deleteAll(List<Role> list);
    void SaveRoleMenu(Role role);
    void deleteMenuByRid(int rid);
    int selectCount(RoleSearchVo roleSearchVo);
    List<Role> selectSecondRoles();

}
