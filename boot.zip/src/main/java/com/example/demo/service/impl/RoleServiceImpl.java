package com.example.demo.service.impl;

import com.example.demo.common.ResultCode;
import com.example.demo.common.exception.CommonException;
import com.example.demo.domain.Role;
import com.example.demo.mapper.RoleMapper;
import com.example.demo.mapper.UserRoleMapper;
import com.example.demo.service.RoleService;
import com.example.demo.vo.RoleSearchVo;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.ArrayList;
import java.util.List;

/**
 * @BelongsProject: sie - 副本
 * @BelongsPackage: com.example.demo.service
 * @Author: jkl
 * @CreateTime: 2020
 * @Description:
 */
@Service
@Transactional
public class RoleServiceImpl implements RoleService {
    @Autowired
    private RoleMapper roleMapper;
    @Autowired
    private UserRoleMapper userRoleMapper;

    /**
     * 增加角色
     * @param role
     */
    @Override
    public void addRole(Role role) throws CommonException {
        Role role1 = roleMapper.selectByName(role.getRoleName());
        if(role1!=null){
            //抛出异常，角色名称存在
            throw new CommonException(ResultCode.ROLENAMEEXIST);
        }else {
            roleMapper.insert(role);
        }
    }

    /**
     * 根据角色id删除角色
     * @param rid
     */
    @Override
    public void deleteRole(Integer rid) {
        userRoleMapper.deleteByRid(rid);
        roleMapper.delete(rid);
    }

    /**
     * 跟新角色
     * @param role
     */
    @Override
    public void updateRole(Role role) throws CommonException {
        Role role1 = roleMapper.selectByName(role.getRoleName());
        if(role1!=null){
            if(role1.getRid()!=role.getRid()){
                //角色名称存在
                throw new CommonException(ResultCode.ROLENAMEEXIST);
            }
        }
        roleMapper.updateRole(role);
    }

    /**
     * 根据条件进行分页查询角色
     * @param roleSearchVo
     * @return
     */
    @Override
    public List<Role> searchRole(RoleSearchVo roleSearchVo) {

        roleSearchVo.setPage((roleSearchVo.getPage()-1)*roleSearchVo.getPageSizes());
        return roleMapper.selectPageRole(roleSearchVo);
    }

    /**
     * 根据角色集合id进行批量删除
     * @param list
     */
    @Override
    public void deleteAll(List<Role> list) {
        ArrayList<Integer> ids = new ArrayList<>();
        for(Role role:list){
            ids.add(role.getRid());
        }
        roleMapper.deleteByIds(ids);
    }

    /**
     * 保存角色所具有的权限
     * @param role
     */
    @Override
    public void SaveRoleMenu(Role role) {
        //roleMapper.deleteMenuByRid(role.getRid());
        if(role.getMenus().size()>0){
            roleMapper.insertRoleMenu(role);
        }

    }

    /**
     * 删除权限根据角色id
     * @param rid
     */
    @Override
    public void deleteMenuByRid(int rid) {
        roleMapper.deleteMenuByRid(rid);
    }

    /**
     * 根据条件查询角色的数量
     * @param roleSearchVo
     * @return
     */
    @Override
    public int selectCount(RoleSearchVo roleSearchVo) {
        return roleMapper.selectCount(roleSearchVo);
    }
    @Override
    public List<Role> selectSecondRoles() {
        return roleMapper.selectSecondRoles();
    }

}
