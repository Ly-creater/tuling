package com.example.demo.service;

import com.example.demo.domain.User;
import com.example.demo.domain.UserRole;
import com.example.demo.vo.UserRoleSearchVo;
import com.example.demo.vo.UserSearchVo;

import java.util.List;
import java.util.Map;

/**
 * @BelongsProject: sie - 副本
 * @BelongsPackage: com.example.demo.service.impl
 * @Author: jkl
 * @CreateTime: 2020
 * @Description:
 */

public interface UserService {
    public User selectByUP(String username, String password);
    public User selectByUsername(String username);
    public void addUser(User user);
    void deleteUser(Integer id);
    void updateUser(User user);
    User selectUser(Integer id);
    //List<User> searchUser(User user);
    List<User> searchUser(UserSearchVo userSearchVo);
    void deleteAll(List<User> list);
    void updateState(int id);
    void saveUserRole(int uid, List<UserRole> userRoles);
    int selectCount(UserSearchVo userSearchVo);
    void deleteRole(Integer id);
    User getPermission(User user);
    List<UserRole> getUserRole(UserRoleSearchVo userRoleSearchVo);
    //User Login(Map<String, String> loginMap, HttpServletResponse response, HttpSession session) throws CommonException;
    String getUserNameById(Map<String, Object> hashMap);



}
