package com.example.demo.service.impl;

import com.example.demo.common.exception.CommonException;
import com.example.demo.domain.User;
import com.example.demo.domain.UserRole;
import com.example.demo.mapper.UserMapper;
import com.example.demo.mapper.UserRoleMapper;
import com.example.demo.service.UserService;
import com.example.demo.utils.CookieUtils;
import com.example.demo.vo.UserRoleSearchVo;
import com.example.demo.vo.UserSearchVo;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Map;

/**
 * @BelongsProject: sie
 * @BelongsPackage: com.example.demo.service
 * @Author: jkl
 * @CreateTime: 2020
 * @Description:
 */
@Service
@Transactional
public class UserServiceImpl implements UserService {
    @Autowired
    private UserMapper userMapper;
    @Autowired
    private UserRoleMapper userRoleMapper;
    @Autowired
    private CookieUtils cookieUtils;
    @Value("${jwt.config.key}")
    private String salt;

    /**
     * 通过用户名和密码查询用户
     *
     * @param username  用户名
     * @param password  密码
     */
    @Override
    public User selectByUP(String username, String password) {
        return userMapper.selectByUP(username, password);
    }

    /**
     * 通过用户名查询用户
     * @param username  用户名
     */
    @Override
    public User selectByUsername(String username) {
        return userMapper.selectByUsername(username);
    }

    /**
     * 新增用户
     * @param user  用户对象
     */
    @Override
    public void addUser(User user) {
        user.setCreateDate(new Date());
        user.setUpdateDate(new Date());
        String password = user.getPassword();
        //对前端明文密码进行md5加密
        //password = new Md5Hash(password, "sielocalhost", 3).toString();
        user.setPassword(password);
        userMapper.insert(user);
    }

    /**
     * 通过id删除用户
     * @param id  用户id
     */
    @Override
    public void deleteUser(Integer id) {
        userMapper.delete(id);
    }

    /**
     * 修改用户
     * @param user  用户对象
     */
    @Override
    public void updateUser(User user) {
        User user1 = userMapper.selectUserById(user.getId());
        //判断是否对密码进行了修改
        //if (!user1.getPassword().equals(user.getPassword())) {
        //    //加密 明文密码
        //    user.setPassword(new Md5Hash(user.getPassword(), "sielocalhost", 3).toString());
        //}
        user.setUpdateDate(new Date());
        userMapper.updateUser(user);
    }

    /**
     * 根据id查询用户
     * @param id 用户id
     */
    @Override
    public User selectUser(Integer id) {
        return userMapper.selectById(id);
    }

    /**
     * 根据条件进行分页查询
     * @param userSearchVo 封装用户信息和分页信息
     */
    @Override
    public List<User> searchUser(UserSearchVo userSearchVo) {
        //处理分页开始数
        userSearchVo.setPage((userSearchVo.getPage() - 1) * userSearchVo.getPageSizes());
        //根据条件查询返回用户集合
        return userMapper.selectByUser(userSearchVo);
    }

    /**
     * 根据id进行批量删除
     * @param list 用户集合
     */
    @Override
    public void deleteAll(List<User> list) {
        ArrayList<Integer> ids = new ArrayList<>();
        for (User user : list) {
            //获取id的集合
            ids.add(user.getId());
        }
        userMapper.deleteByIds(ids);
    }

    /**
     * 修改状态根据用户id
     * @param id  用户id
     */
    @Override
    public void updateState(int id) {
        User user = userMapper.selectUserById(id);
        user.setState(false);
        user.setUpdateDate(new Date());
        userMapper.updateUser(user);
    }

    /**
     * 保存用户的角色信息
     * @param uid   用户id
     * @param userRoles  选择的角色集合
     */
    @Override
    public void saveUserRole(int uid,List<UserRole> userRoles) {
        //先删除原有的角色
        deleteRole(uid);
        if(userRoles.size()>0){
            for(UserRole userRole:userRoles){
                //生效时间
                Date start=userRole.getStartDate();
                //失效时间
                Date end=userRole.getEndDate();
                //判断当前时间是否 在生效和失效时间之间
                if(after(end)&&before(start)) {
                    //判断是否为无效
                    if (!userRole.getUrState()) {
                        //改为有效
                        userRole.setUrState(true);
                    }
                }else {
                    //改为无效
                    userRole.setUrState(false);
                }
            }
            userRoleMapper.saveUserRole(userRoles);
        }

    }

    /**
     * 根据条件查询用户的数量
     * @param userSearchVo 封装用户信息和分页信息
     */
    @Override
    public int selectCount(UserSearchVo userSearchVo) {
        return userMapper.selectCount(userSearchVo);
    }

    /**
     * 根据用户id进行删除
     * @param uid 用户id
     */
    @Override
    public void deleteRole(Integer uid) {
        userMapper.deleteRole(uid);
    }

    /**
     * 根据用户id获取角色，和权限
     * @param user  用户的基本信息
     */
    @Override
    public User getPermission(User user) {
        User user1 = userMapper.selectAllTable(user.getId());
        if(user1==null){
            user1=user;
        }
        return user1;
    }

    /**
     * 查询拥有的角色和未拥有的角色
     * @param userRoleSearchVo
     */
    @Override
    public List<UserRole> getUserRole(UserRoleSearchVo userRoleSearchVo) {
        //处理分页起始页
        userRoleSearchVo.setPage((userRoleSearchVo.getPage() - 1) * userRoleSearchVo.getPageSizes());
        //role与user_role的左连接查询
        List<UserRole> userRoles1 = userRoleMapper.selectSetRole(userRoleSearchVo);
        for(UserRole userRole:userRoles1){
            if(userRole.getUrState()==null){
                userRole.setUrState(true);
                userRole.setRid(null);
                userRole.setUid(userRoleSearchVo.getUid());
            }
        }
        return userRoles1;
    }

    /**
     * 用户登录
     //* @param loginMap
     //* @param response
     //* @param session
     * @return
     * @throws CommonException
     */
    //@Override
    //public User Login(Map<String, String> loginMap, HttpServletResponse response, HttpSession session) throws CommonException {
    //    String username = loginMap.get("username");
    //    String password = loginMap.get("password");
    //    String code = loginMap.get("code");
    //    String autoLogin = loginMap.get("autoLogin");
    //    String identityCode =(String) session.getAttribute("IdentityCode");
    //    //判断验证码是否正确
    //    if(!identityCode.equals(code)){
    //        throw new CommonException(ResultCode.CODEERROR);
    //    }else{
    //        password = new Md5Hash(password, salt, 3).toString();
    //        //构建upToken
    //        UsernamePasswordToken upToken = new UsernamePasswordToken(username, password);
    //        Subject subject = SecurityUtils.getSubject();
    //        //设置是否自动登录
    //        upToken.setRememberMe("true".equals(autoLogin));
    //        //调用shiro的login方法
    //        subject.login(upToken);
    //        String sid = subject.getSession().getId().toString();
    //        cookieUtils.createCookie("USER_COOKIE",sid,response);
    //        User user = (User)subject.getPrincipal();
    //        //获取所有角色（除了系统管理员外）
    //        //List<Role> roles = roleService.selectSecondRoles();
    //        User permission = getPermission(user);
    //        if(permission.getState()){
    //            if(permission.getRoles()!=null && permission.getRoles().size()>0 ){
    //                //判断角色中是否包含“用户管理员角色“
    //                //for(Role role:permission.getRoles()){
    //                //    if("all".equals(role.getRoleCode())){
    //                //        permission.setRoles(roles);
    //                //    }
    //                //}
    //                return permission;
    //            }else {
    //                throw new CommonException(ResultCode.PERMISSIONISNULL);
    //            }
    //        }else {
    //            throw new CommonException(ResultCode.USERNOSTATE);
    //        }
    //    }
    //}

    @Override
    public String getUserNameById(Map<String, Object> hashMap) {
        userMapper.getUserNameById(hashMap);
        System.out.println(hashMap);
        return hashMap.get("username").toString();
    }


    /**
     * 定时任务：对user_role中过期的角色设置为无效
     */
    @Scheduled(fixedRate = 1000*60*60*2)
    public void task(){
        //查询user_role表中的数据
        List<UserRole> userRoles = userRoleMapper.selectAll();
        for(UserRole userRole:userRoles){
            Date start=userRole.getStartDate();
            Date end=userRole.getEndDate();
            //判断当前时间是否在生效和失效时间之间
            if(after(end)&&before(start)) {
                //判断是否失效
                if (!userRole.getUrState()) {
                    userRole.setUrState(true);
                }
            }else{
                userRole.setUrState(false);
            }
        }
        userRoleMapper.updateUrState(userRoles);
    }

    public boolean after(Date date){
        Date date1 = new Date();
        //当传入的时间为null时，默认为在当前时间之后
        if(date==null){
            return true;
        }else{
            return date.after(date1);
        }
    }

    public boolean before(Date date){
        Date date1 = new Date();
        //当传入的时间为null时，默认为在当前时间之前
        if(date==null){
            return true;
        }else{
            return date.before(date1);
        }
    }

}
