package com.example.demo.service;

import com.example.demo.common.exception.CommonException;
import com.example.demo.domain.Menu;

import java.util.List;

/**
 * @BelongsProject: sie - 副本
 * @BelongsPackage: com.example.demo.service.impl
 * @Author: jkl
 * @CreateTime: 2020
 * @Description:
 */

public interface MenuService {
    void addMenu(Menu menu) throws CommonException;
    void deleteMenu(Integer id);
    void updateMenu(Menu menu) throws CommonException;
    Menu selectById(Integer id);
    List<Menu> searchMenu(Menu menu);
    void deleteAll(List<Menu> list);
    List<Menu> selectAll();
}
