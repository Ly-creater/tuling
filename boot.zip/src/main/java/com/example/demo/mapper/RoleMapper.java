package com.example.demo.mapper;

import com.example.demo.domain.Role;
import com.example.demo.vo.RoleSearchVo;

import java.util.List;

/**
 * @BelongsProject: sie - 副本
 * @BelongsPackage: com.example.demo.mapper
 * @Author: jkl
 * @CreateTime: 2020
 * @Description:
 */
public interface RoleMapper {
    void insert(Role role);
    void delete(int rid);
    void updateRole(Role role);
    Role selectById(int id);
    void deleteByIds(List list);
    void insertRoleMenu(Role role);
    void deleteMenuByRid(int rid);
    int selectCount(RoleSearchVo roleSearchVo);
    Role selectByName(String roleName);
    List<Role> selectSecondRoles();
    List<Role> selectPageRole(RoleSearchVo roleSearchVo);

}
