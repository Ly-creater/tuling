package com.example.demo.mapper;

import com.example.demo.domain.Menu;

import java.util.List;

/**
 * @BelongsProject: sie - 副本
 * @BelongsPackage: com.example.demo.mapper
 * @Author: jkl
 * @CreateTime: 2020
 * @Description:
 */
public interface MenuMapper {
    void insert(Menu Menu);
    void delete(int mid);
    void updateMenu(Menu menu);
    Menu selectById(int mid);
    List<Menu> selectByMenu(Menu Menu);
    void deleteByIds(List<Menu> list);
    Menu selectByName(String menuName);
    List<Menu> selectAll();
}
