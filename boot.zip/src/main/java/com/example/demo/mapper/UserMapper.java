package com.example.demo.mapper;

import com.example.demo.domain.User;
import com.example.demo.vo.UserSearchVo;

import java.util.List;
import java.util.Map;

/**
 * @BelongsProject: sie
 * @BelongsPackage: com.example.demo.dao
 * @Author: jkl
 * @CreateTime: 2020
 * @Description:
 */
public interface UserMapper{
    User selectByUP(String username,String password);
    User selectByUsername(String username);
    void insert(User user);
    void delete(int id);
    void updateUser(User user);
    User selectById(int id);
    List<User> selectByUser(UserSearchVo userSearchVo);
    void deleteByIds(List list);
    int selectCount(UserSearchVo userSearchVo);
    void deleteRole(int id);
    User selectUserById(int id);
    User selectAllTable(int uid);
    void getUserNameById(Map<String, Object> hashMap);
}
