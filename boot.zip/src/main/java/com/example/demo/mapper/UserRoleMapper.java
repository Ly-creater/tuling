package com.example.demo.mapper;

import com.example.demo.domain.UserRole;
import com.example.demo.vo.UserRoleSearchVo;

import java.util.List;

/**
 * @BelongsProject: sie - 副本
 * @BelongsPackage: com.example.demo.mapper
 * @Author: jkl
 * @CreateTime: 2020
 * @Description:
 */
public interface UserRoleMapper {
    List<UserRole> selectUserRole(int uid);
    void saveUserRole(List<UserRole> list);
    List<UserRole> selectAll();
    void updateUrState(List<UserRole> list);
    void deleteByRid(int rid);
    List<UserRole> selectSetRole(UserRoleSearchVo userRoleSearchVo);
}
