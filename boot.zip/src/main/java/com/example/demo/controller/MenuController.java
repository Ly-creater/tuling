package com.example.demo.controller;

import com.example.demo.common.Result;
import com.example.demo.common.ResultCode;
import com.example.demo.common.exception.CommonException;
import com.example.demo.domain.Menu;
import com.example.demo.service.MenuService;
import com.example.demo.vo.MenuSearchVo;
import com.github.pagehelper.Page;
import com.github.pagehelper.PageHelper;
import com.github.pagehelper.PageInfo;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;

/**
 * @BelongsProject: sie - 副本
 * @BelongsPackage: com.example.demo.controller
 * @Author: jkl
 * @CreateTime: 2020
 * @Description:
 */
@CrossOrigin(origins = "*",allowCredentials="true",maxAge = 1800,methods={RequestMethod.POST,RequestMethod.DELETE,RequestMethod.PUT,RequestMethod.GET})
@RestController
@RequestMapping(value = "/menu")
public class MenuController {
    @Autowired
    private MenuService menuService;

    /**
     * 增加菜单
     * @param menu
     * @return
     * @throws CommonException
     */
    //@RequiresPermissions(value = "menu:add")
    @RequestMapping(value = "",method = RequestMethod.POST)
    public Result addMenu(@RequestBody Menu menu) throws CommonException {
        if(menu!=null){
            menuService.addMenu(menu);
            return new Result(ResultCode.SUCCESS);
        }
        return new Result(ResultCode.DATAISNULL);
    }

    /**
     * 删除菜单
     * @param rid
     * @return
     */
    //@RequiresPermissions(value = "menu:delete")
    @RequestMapping(value = "/{rid}",method = RequestMethod.DELETE)
    public Result deleteRole(@PathVariable int rid){
        menuService.deleteMenu(rid);
        return new Result(ResultCode.SUCCESS);
    }

    /**
     * 跟新菜单
     * @param menu
     * @return
     * @throws CommonException
     */
    //@RequiresPermissions(value = "menu:update")
    @RequestMapping(value = "",method = RequestMethod.PUT)
    public Result updateMenu(@RequestBody Menu menu) throws CommonException {
        if(menu!=null){
            menuService.updateMenu(menu);
            return new Result(ResultCode.SUCCESS);
        }
        return new Result(ResultCode.DATAISNULL);

    }

    /**
     *根据id查询菜单
     * @param id
     * @return
     */
    //@RequiresPermissions(value = "menu:search")
    @RequestMapping(value = "/{id}",method = RequestMethod.GET)
    public Result selectById(@PathVariable int id){
        Menu menu = menuService.selectById(id);
        return new Result(ResultCode.SUCCESS,menu);
    }

    /**
     * 根据条件进行分页查询菜单
     * @param menuSearchVo  对菜单信息和分页信息进行封装
     * @return
     */
    //@RequiresPermissions(value = "menu:search")
    @RequestMapping(value = "/search",method = RequestMethod.POST)
    public Result search(@RequestBody MenuSearchVo menuSearchVo){
        //获取第几页
        int page = menuSearchVo.getPage();
        //获取每页的数量
        int pageSizes = menuSearchVo.getPageSizes();
        Menu menu = menuSearchVo.getMenu();
        //利用pageHelp进行分页
        PageHelper.startPage(page,pageSizes);
        Page<Menu> menus = (Page<Menu>)menuService.searchMenu(menu);
        //防止前端穿过来的页数大于最大页数，就查询最大页数的数据
        if (page>menus.getPages()) {
            PageHelper.startPage(menus.getPages(),pageSizes);
            menus = (Page<Menu>)menuService.searchMenu(menu);
        }
        PageInfo<Menu> menuPageInfo = new PageInfo<Menu>(menus);
        //返回状态信息及分页信息
        return new Result(ResultCode.SUCCESS,menuPageInfo);
    }

    /**
     * 批量删除菜单
     * @param list
     * @return
     */
    //@RequiresPermissions(value = "menu:delete")
    @RequestMapping(value="",method = RequestMethod.DELETE)
    public Result deleteAll(@RequestBody List<Menu> list){
        menuService.deleteAll(list);
        return new Result(ResultCode.SUCCESS);
    }

    /**
     * 查询所有菜单
     * @return
     */
    //@RequiresPermissions(value = "menu:search")
    @RequestMapping(value="/all",method = RequestMethod.GET)
    public Result selectAll(){
        List<Menu> menus = menuService.selectAll();
        return new Result(ResultCode.SUCCESS,menus);
    }
}
