package com.example.demo.controller;

import com.example.demo.common.Result;
import com.example.demo.common.ResultCode;
import com.example.demo.common.exception.CommonException;
import com.example.demo.domain.Role;
import com.example.demo.service.RoleService;
import com.example.demo.vo.Page;
import com.example.demo.vo.RoleSearchVo;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;

/**
 * @BelongsProject: sie - 副本
 * @BelongsPackage: com.example.demo.controller
 * @Author: jkl
 * @CreateTime: 2020
 * @Description:
 */
@CrossOrigin(origins = "*",allowCredentials="true",maxAge = 1800,methods={RequestMethod.POST,RequestMethod.DELETE,RequestMethod.PUT,RequestMethod.GET})
@RestController
@RequestMapping(value = "/role")
public class RoleController {
    @Autowired
    private RoleService roleService;

    /**
     * 增加角色
     * @param role
     * @return
     * @throws CommonException
     */
    //@RequiresPermissions(value = "role:add")
    @RequestMapping(value = "",method = RequestMethod.POST)
    public Result addRole(@RequestBody Role role) throws CommonException {
        if(role!=null){
            //调用service进行增加
            roleService.addRole(role);
            return new Result(ResultCode.SUCCESS);
        }
        //如果数据为null,返回数据为空进行提示
        return new Result(ResultCode.DATAISNULL);

    }

    /**
     * 根据id删除角色
     * @param rid
     * @return
     */
    //@RequiresPermissions(value = "role:delete")
    @RequestMapping(value = "/{rid}",method = RequestMethod.DELETE)
    public Result deleteRole(@PathVariable int rid){
        roleService.deleteRole(rid);
        return new Result(ResultCode.SUCCESS);
    }

    /**
     * 跟新角色
     * @param role
     * @return
     * @throws CommonException
     */
    //@RequiresPermissions(value = "role:update")
    @RequestMapping(value = "",method = RequestMethod.PUT)
    public Result updateRole(@RequestBody Role role) throws CommonException {
        if (role!=null) {
            roleService.updateRole(role);
            return new Result(ResultCode.SUCCESS);
        }
        return new Result(ResultCode.DATAISNULL);
    }



    /**
     * 根据条件进行分页查询角色
     * @param roleSearchVo 对角色信息和分页信息进行封装
     * @return
     */
    //@RequiresPermissions(value = "role:search")
    @RequestMapping(value = "/search",method = RequestMethod.POST)
    public Result search(@RequestBody RoleSearchVo roleSearchVo){
        //获取第几页
        int page = roleSearchVo.getPage();
        //获取每页的数量
        int pageSizes = roleSearchVo.getPageSizes();
        List<Role> roles = roleService.searchRole(roleSearchVo);
        //对集合信息进行封装
        Page<Role>page1 = new Page<Role>(pageSizes, roles,roleService.selectCount(roleSearchVo),page);
        //当传入的页数大于最大页数时，就查询最大页数的数据
        if (page>page1.getPageNum()&& page1.getPageNum()>0) {
            roles = roleService.searchRole(new RoleSearchVo(roleSearchVo.getRole(), page1.getPageNum(), roleSearchVo.getPageSizes()));
            page1 = new Page<Role>(pageSizes, roles,roleService.selectCount(roleSearchVo),page1.getPageNum());
        }
        return new Result(ResultCode.SUCCESS,page1);
    }

    /**
     * 批量删除角色
     * @param list
     * @return
     */
    //@RequiresPermissions(value = "role:delete")
    @RequestMapping(value="",method = RequestMethod.DELETE)
    public Result deleteAll(@RequestBody List<Role> list){
        roleService.deleteAll(list);
        return new Result(ResultCode.SUCCESS);
    }

    /**
     * 为角色设置权限
     * @param role
     * @return
     */
    //@RequiresPermissions(value = "role:menu")
    @RequestMapping(value = "/menu",method = RequestMethod.POST)
    public Result saveRole(@RequestBody Role role){
        //先清除原有的权限
        roleService.deleteMenuByRid(role.getRid());
        //保存权限
        roleService.SaveRoleMenu(role);
        return new Result(ResultCode.SUCCESS);
    }

}
