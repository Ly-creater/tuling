package com.example.demo.controller;

import com.example.demo.common.Result;
import com.example.demo.common.ResultCode;
import com.example.demo.domain.Role;
import com.example.demo.domain.User;
import com.example.demo.domain.UserRole;
import com.example.demo.service.RoleService;
import com.example.demo.service.UserService;
import com.example.demo.utils.IdentityCode;
import com.example.demo.vo.Page;
import com.example.demo.vo.RoleSearchVo;
import com.example.demo.vo.UserRoleSearchVo;
import com.example.demo.vo.UserSearchVo;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import javax.servlet.http.HttpSession;
import java.util.List;

/**
 * @BelongsProject: sie
 * @BelongsPackage: com.example.demo.controller
 * @Author: jkl
 * @CreateTime: 2020
 * @Description:
 */
@CrossOrigin(origins = "*",allowCredentials="true",maxAge = 1800,methods={RequestMethod.POST,RequestMethod.DELETE,RequestMethod.PUT,RequestMethod.GET})
@RestController
@RequestMapping(value = "/user")
public class UserController {
    @Autowired
    private UserService userService;
    @Autowired
    private RoleService roleService;



    /**
     * 通过id查询user
     * @param id
     * @return
     */
    //@RequiresPermissions(value = "user:search")
    @RequestMapping(value="/{id}",method = RequestMethod.POST)
    public Result selectById(@PathVariable int id){
        return new Result(ResultCode.SUCCESS,userService.selectUser(id));
    }

    /**
     * 通过id删除用户
     * @param id
     * @return
     */
    //@RequiresPermissions(value = "user:delete")
    @RequestMapping(value="/{id}",method = RequestMethod.DELETE)
    public Result deleteById(@PathVariable int id){
        userService.deleteUser(id);
        return new Result(ResultCode.SUCCESS);
    }

    /**
     * 修改用户
     * @param user
     * @return
     */
    //@RequiresPermissions(value = "user:update")
    @RequestMapping(value="",method = RequestMethod.PUT)
    public Result updateUser(@RequestBody User user){
        if (user!=null) {
            User user1 = userService.selectByUsername(user.getUsername());
            //保证用户名在数据库中不重复不重复
            if(user1!=null){
                if(!user1.getId().equals(user.getId())){
                    return new Result(ResultCode.USERNAMEEXITE);
                }
            }
            userService.updateUser(user);
            return new Result(ResultCode.SUCCESS);
        }
        return new Result(ResultCode.DATAISNULL);

    }

    /**
     * 设置无效状态
     * @param id
     * @return
     */
    //@RequiresPermissions("user:update")
    @RequestMapping(value="/{id}",method = RequestMethod.PUT)
    public Result updateUser(@PathVariable int id){
        userService.updateState(id);
        return new Result(ResultCode.SUCCESS);

    }

    /**
     * 增加user
     * @param user
     * @return
     */
    //@RequiresPermissions(value = "user:add")
    @RequestMapping(value="",method = RequestMethod.POST)
    public Result insertUser(@RequestBody User user){
        if (user!=null) {
            User user1 = userService.selectByUsername(user.getUsername());
            //保证用户名在数据库中不重复不重复
            if(user1!=null){
                return new Result(ResultCode.USERNAMEEXITE);
            }
            userService.addUser(user);
            return new Result(ResultCode.SUCCESS);
        }
        return new Result(ResultCode.DATAISNULL);

    }


    /**
     * 批量删除用户
     * @param list
     * @return
     */
    //@RequiresPermissions(value = "user:delete")
    @RequestMapping(value="",method = RequestMethod.DELETE)
    public Result deleteAll(@RequestBody List<User> list){
        userService.deleteAll(list);
        return new Result(ResultCode.SUCCESS);
    }

    /**
     * 查询所有user和根据条件查询user
     *      通过构造一个searchVo对象对前端传来的数据进行接收
     * @param userSearchVo
     * @return
     */
    //@RequiresPermissions(value = "user:search")
    @RequestMapping(value="/search",method = RequestMethod.POST)
    public Result search(@RequestBody UserSearchVo userSearchVo){
        //获取起始页
        int page = userSearchVo.getPage();
        //获取每页数量
        int pageSizes = userSearchVo.getPageSizes();
        //根据添加和分页进行查询
        List<User> users = userService.searchUser(userSearchVo);
        //封装用户信息和分页信息
        Page<User> userPage = new Page<User>(pageSizes, users, userService.selectCount(userSearchVo),page);
        //UserSearchVo searchVo = new UserSearchVo();
        //当传入的页数大于最大页数时，就查询最大页数的数据
        if (page>userPage.getPageNum() && userPage.getPageNum()>0) {
            //BeanUtils.copyProperties(userSearchVo,searchVo);
            userSearchVo.setPage(userPage.getPageNum());
            users = userService.searchUser(userSearchVo);
            userPage = new Page<User>(pageSizes, users,userService.selectCount(userSearchVo),userPage.getPageNum());
        }

        return new Result(ResultCode.SUCCESS,userPage);
    }

    /**
     * 登录功能
     * @param loginMap
     * @param response
     * @param session
     * @return
     * @throws Exception
     */
    //@RequestMapping(value = "/login", method = RequestMethod.POST)
    //public Result login(@RequestBody Map<String, String> loginMap, HttpServletResponse response, HttpSession session) throws Exception {
    //    User user = userService.Login(loginMap, response, session);
    //    return new Result(ResultCode.SUCCESS,user);
    //}

    /**
     * 保存用户角色
     * @param userRoleSearchVo
     * @return
     */
    //@RequiresPermissions(value = "user:role")
    @RequestMapping(value = "/role",method = RequestMethod.POST)
    public Result saveRole(@RequestBody UserRoleSearchVo userRoleSearchVo){
        int uid = userRoleSearchVo.getUid();
        List<UserRole> userRoles = userRoleSearchVo.getUserRoles();
        userService.saveUserRole(uid,userRoles);
        return new Result(ResultCode.SUCCESS);


    }
    //生成验证码
    @RequestMapping(value = "/code",method = RequestMethod.GET)
    public Result getIdentityCode(HttpSession session){
        String code = IdentityCode.getCode();
        session.setAttribute("IdentityCode",code);
        return new Result(ResultCode.SUCCESS,code);
    }
    /**
     * 注册user
     * @param user
     * @return
     */
    @RequestMapping(value="/registry",method = RequestMethod.POST)
    public Result registryUser(@RequestBody User user){
        if (user!=null) {
            User user1 = userService.selectByUsername(user.getUsername());
            //保证用户名在数据库中不重复不重复
            if(user1!=null){
                return new Result(ResultCode.USERNAMEEXITE);
            }
            userService.addUser(user);
            return new Result(ResultCode.SUCCESS);
        }
        return new Result(ResultCode.DATAISNULL);

    }


    /**
     * 根据分页信息查询UserRole
     * @param userRoleSearchVo
     * @return
     */
    //@RequiresPermissions(value = "user:role")
    @RequestMapping(value = "/userRole",method = RequestMethod.POST)
    public Result selectUserRole(@RequestBody UserRoleSearchVo userRoleSearchVo){
        int page = userRoleSearchVo.getPage();
        int pageSizes=userRoleSearchVo.getPageSizes();
        //通过用户id查询UserRole
        List<UserRole> userRole = userService.getUserRole(userRoleSearchVo);
        RoleSearchVo roleSearchVo = new RoleSearchVo();
        roleSearchVo.setRole(new Role());
        Page<UserRole> page1 = new Page<UserRole>(pageSizes, userRole,roleService.selectCount(roleSearchVo),page);
        if (page>page1.getPageNum()&& page1.getPageNum()>0) {
            userRoleSearchVo.setPage(page1.getPageNum());
            //new UserRoleSearchVo(userRoleSearchVo.getUid(),new ArrayList<UserRole>(),page1.getPageNum(),pageSizes)
            userRole = userService.getUserRole(userRoleSearchVo);
            page1 = new Page<UserRole>(pageSizes, userRole,roleService.selectCount(new RoleSearchVo()),page1.getPageNum());
        }
        return new Result(ResultCode.SUCCESS,page1);
    }
    @RequestMapping(value = "/logout",method = RequestMethod.POST)
    public Result logout() {
        //SecurityUtils.getSubject().logout();
        return new Result(ResultCode.SUCCESS);
    }

}
