package com.example.demo.common.handler;


import com.example.demo.common.Result;
import com.example.demo.common.ResultCode;
import com.example.demo.common.exception.CommonException;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.ResponseBody;
/**
 * @BelongsProject: sie
 * @BelongsPackage: com.example.demo.common
 * @Author: jkl
 * @CreateTime: 2020
 * @Description:
 */
/**
 * 自定义的公共异常处理器
 *      1.声明异常处理器
 *      2.对异常统一处理
 */
@ControllerAdvice
public class CommonExceptionHandler {

    @ResponseBody
    @ExceptionHandler(value = Exception.class)
    public Result error(Exception e) {
        Result result = null;
        if(e.getClass() == CommonException.class) {
            result = new Result(((CommonException) e).getResultCode());
            //}else if(e.getClass()==UnauthorizedException.class ||  e.getClass()== UnauthenticatedException.class){
            //    //未授权
            //    result = new Result(ResultCode.UNAUTHORISE);
            //}else if(e.getClass() == AuthenticationException.class){
            //    //用户名密码不正确
            //    result = new Result(ResultCode.USERNAMEPASSWORDERROR);
            //}
        }else {
            //系统异常
            result = new Result(ResultCode.SERVER_ERROR);
        }
        return result;
    }

}
