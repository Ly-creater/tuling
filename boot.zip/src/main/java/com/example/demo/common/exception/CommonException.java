package com.example.demo.common.exception;


import com.example.demo.common.ResultCode;
import lombok.Getter;
/**
 * @BelongsProject: sie
 * @BelongsPackage: com.example.demo.common
 * @Author: jkl
 * @CreateTime: 2020
 * @Description:
 */
/**
 * 自定义异常
 */
@Getter
public class CommonException extends Exception  {

    private ResultCode resultCode;

    public CommonException(ResultCode resultCode) {
        this.resultCode = resultCode;
    }
}
