package com.example.demo.common;
/**
 * @BelongsProject: sie
 * @BelongsPackage: com.example.demo.common
 * @Author: jkl
 * @CreateTime: 2020
 * @Description:
 */

public enum ResultCode {

    SUCCESS(true,1000,"操作成功！"),
    //---系统错误返回码-----
    FAIL(false,1001,"操作失败"),
    UNAUTHENTICATED(false,1002,"您还未登录"),
    UNAUTHORISE(false,1003,"您不具有此操作的权利"),
    USERNAMEPASSWORDERROR(false,1004,"用户名或密码错误"),
    SERVER_ERROR(false,1005,"抱歉，系统繁忙，请稍后重试！"),
    USERNAMEEXITE(false,1006,"用户名已存在！"),
    MENUNAEMNOTEXIST(false,1007,"上级菜单名不存在"),
    DATAISNULL(false,1008,"数据不能为空"),
    MENUNAMEEXIST(false,1009,"菜单名称已存在！"),
    CODEERROR(false,1010,"验证码错误！"),
    PERMISSIONISNULL(false,1011,"您不具有任何权限，无法进行访问，请联系管理员！"),
    USERNOSTATE(false,1012,"对不起你的账号已失效，请联系管理员！"),
    ROLENAMEEXIST(false,1013,"角色名称已存在！");


    //操作是否成功
    boolean success;
    //操作代码
    int code;
    //提示信息
    String message;

    ResultCode(boolean success,int code, String message){
        this.success = success;
        this.code = code;
        this.message = message;
    }

    public boolean success() {
        return success;
    }

    public int code() {
        return code;
    }

    public String message() {
        return message;
    }

}
