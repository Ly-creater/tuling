package com.example.demo.vo;

import lombok.AllArgsConstructor;
import lombok.NoArgsConstructor;

import java.util.List;

/**
 * @BelongsProject: sie - 副本
 * @BelongsPackage: com.example.demo.vo
 * @Author: jkl
 * @CreateTime: 2020
 * @Description:
 */
@AllArgsConstructor
@NoArgsConstructor
public class Page<T> {
    private int total;
    private int pageNum;
    private int pageSize;
    private List<T> list;
    private int page;//前端传来的页码

    public int getPageNum() {
        return this.total%pageSize==0 ? this.total/pageSize : (this.total/pageSize)+1;
    }
    public int getTotal() {
        return total;
    }
    public void setTotal(int total) {
        this.total = total;
    }
    public void setPageNum(int pageNum) {
        this.pageNum = pageNum;
    }
    public int getPageSize() {
        return pageSize;
    }
    public void setPageSize(int pageSize) {
        this.pageSize = pageSize;
    }
    public List<T> getList() {
        return list;
    }
    public void setList(List<T> list) {
        this.list = list;
    }
    public int getPage() {
        return page;
    }
    public void setPage(int page) {
        this.page = page;
    }
    public Page(int pageSize, List<T> list, int total, int page) {
        this.pageSize = pageSize;
        this.list = list;
        this.total=total;
        this.page=page;
    }
}
