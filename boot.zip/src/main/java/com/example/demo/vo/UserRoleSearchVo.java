package com.example.demo.vo;

import com.example.demo.domain.UserRole;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.List;

/**
 * @BelongsProject: sie
 * @BelongsPackage: com.example.demo.common
 * @Author: jkl
 * @CreateTime: 2020
 * @Description:
 */
@Data
@AllArgsConstructor
@NoArgsConstructor
public class UserRoleSearchVo {
    private int uid;
    private List<UserRole> userRoles;
    private int page;
    private int pageSizes;
}
