package com.example.demo.vo;

import com.example.demo.domain.Menu;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * @BelongsProject: sie
 * @BelongsPackage: com.example.demo.common
 * @Author: jkl
 * @CreateTime: 2020
 * @Description:
 */
@Data
@AllArgsConstructor
@NoArgsConstructor
public class MenuSearchVo {
    private Menu menu;
    private int page;
    private int pageSizes;
}
