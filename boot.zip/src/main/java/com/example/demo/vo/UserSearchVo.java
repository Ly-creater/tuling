package com.example.demo.vo;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * @BelongsProject: sie
 * @BelongsPackage: com.example.demo.common
 * @Author: jkl
 * @CreateTime: 2020
 * @Description:
 */
@Data
@AllArgsConstructor
@NoArgsConstructor
public class UserSearchVo {
    private String username;
    private String name;
    private String createDate;
    private String updateDate;
    private Boolean state;
    private int page;
    private int pageSizes;
}
