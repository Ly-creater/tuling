/*
 Navicat Premium Data Transfer

 Source Server         : database1
 Source Server Type    : MySQL
 Source Server Version : 80020
 Source Host           : localhost:3306
 Source Schema         : manager

 Target Server Type    : MySQL
 Target Server Version : 80020
 File Encoding         : 65001

 Date: 31/08/2020 22:14:28
*/

SET NAMES utf8mb4;
SET FOREIGN_KEY_CHECKS = 0;

-- ----------------------------
-- Table structure for user
-- ----------------------------
DROP TABLE IF EXISTS `user`;
CREATE TABLE `user`  (
  `id` int(0) NOT NULL AUTO_INCREMENT COMMENT '用户编号',
  `username` varchar(50) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL COMMENT '用户名',
  `name` varchar(50) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL COMMENT '姓名',
  `sex` varchar(10) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL COMMENT '性别',
  `mobile` varchar(20) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL,
  `email` varchar(50) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL,
  `createDate` datetime(0) NULL DEFAULT NULL,
  `updateDate` datetime(0) NULL DEFAULT NULL,
  `state` tinyint(1) UNSIGNED ZEROFILL NOT NULL DEFAULT 1,
  `password` varchar(50) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL,
  `info` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT '',
  `isVisible` tinyint(1) NOT NULL DEFAULT 1,
  PRIMARY KEY (`id`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 59 CHARACTER SET = utf8 COLLATE = utf8_general_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of user
-- ----------------------------
INSERT INTO `user` VALUES (28, 'admin', 'admin', '男', '13265657878', '13265657878@qq.com', '2020-07-11 00:00:00', '2020-07-30 15:29:44', 1, 'a4e8ab5a72962860dc049663af6acfde', '12345', 1);
INSERT INTO `user` VALUES (29, '12345', 'admin', '男', '12699998888', '12699998888@163.com', '2020-06-28 12:41:47', '2020-07-02 16:49:21', 1, '936dcc5b8476909548931ab358dc0caa', '12334', 0);
INSERT INTO `user` VALUES (30, '132342', '12', '男', '123132223423', '123132223423@qq.com', '2020-07-11 00:00:00', '2020-07-13 17:40:05', 0, 'b7fcc7509bd8383b9726d06bce79b729', '123434', 0);
INSERT INTO `user` VALUES (31, '1323421234', '12', '男', '123132223423', '123132223423@qq.com', '2020-06-28 00:00:00', '2020-07-11 15:51:23', 1, '626cb3652479995ee06031371662d9ff', '234', 0);
INSERT INTO `user` VALUES (36, '12341324', '1234', '女', '12345', '12345', '2020-07-01 04:49:41', '2020-07-11 15:55:53', 0, '084e695e86ca4467c8b9901656af6dfd', '12345', 0);
INSERT INTO `user` VALUES (39, '3456', '3456', '男', '123456', '234', '2020-07-02 10:02:15', '2020-07-02 13:48:32', 1, '5202082396cb6f2f119abfaa696c5866', '23456', 0);
INSERT INTO `user` VALUES (40, '34562345', '3456', '男', '234567', '1223', '2020-07-02 00:00:00', '2020-07-11 00:00:00', 0, '5b1356c0f2fb3f4d5805794b6b77492d', '23456', 0);
INSERT INTO `user` VALUES (41, '4rty', '2345', '女', '345', '45', '2020-07-02 00:00:00', '2020-07-11 00:00:00', 0, 'afeb6b76175cb6bd0a216d93cc0953b5', '345634', 0);
INSERT INTO `user` VALUES (42, '4rty34', '234534', '男', '34534', '4534', '2020-07-02 00:00:00', '2020-07-11 00:00:00', 1, '94b5cc2d5b2e807a064722982a794e0b', '34563434', 0);
INSERT INTO `user` VALUES (43, '4rty34343', '234534', '男', '34534', '4534', '2020-07-01 00:00:00', '2020-07-11 15:46:31', 1, 'd47584940f3597c0dfe1a6feb4df2f11', '34563434', 0);
INSERT INTO `user` VALUES (44, 'jack', 'm', '男', 'sfda', 'sfda', NULL, NULL, 1, '1af75fafdf69f2267084cb0d7034a139', NULL, 0);
INSERT INTO `user` VALUES (45, 'jackdsaf', 'jkasd', '女', '1236566899', '1236566899@qq.com', '2020-07-11 16:29:28', '2020-07-11 16:29:28', 0, 'de172f256f199292502919a1136a0257', 'sdfasd', 0);
INSERT INTO `user` VALUES (46, '1', '1', '女', '15479863698', '56566@163.com', '2020-07-07 13:43:27', '2020-08-06 08:40:35', 1, '7ea0bc89b2faed064055136cbc4383af', 'dafdsd', 1);
INSERT INTO `user` VALUES (47, '2', '2', '男', '13366666666', '12343234@qq.com', '2020-07-16 16:16:03', '2020-07-30 15:30:12', 1, 'c293ad62429c9e497198f8857be07436', '232354', 1);
INSERT INTO `user` VALUES (48, '3', '3', '男', '18888888888', '234324@qq.com', '2020-07-16 16:25:10', '2020-07-17 01:15:14', 1, 'aa2302f57b5a54cc5036e83080a124a3', '234', 1);
INSERT INTO `user` VALUES (49, '4', '4', '男', '19999999999', '4@qq.com', '2020-07-17 01:21:52', '2020-07-29 15:34:02', 1, '73c480e623fc21489d23e4ab2b075792', '4', 1);
INSERT INTO `user` VALUES (50, '333', '33', '男', '13226265454', '2555@qq.com', '2020-07-21 11:44:15', '2020-07-21 11:44:15', 1, '7ea0bc89b2faed064055136cbc4383af', 'd', 0);
INSERT INTO `user` VALUES (51, '55555', '5555', '男', '15888887777', '3232@11.com', '2020-07-23 22:07:09', '2020-07-23 22:07:09', 0, '6181e6836daaacad1476be2ae07d84a6', 'sdf', 0);
INSERT INTO `user` VALUES (52, '5', '5', '男', '15899996666', '157@qq.com', '2020-07-23 22:37:38', '2020-08-06 13:49:58', 1, '95f4ef889dc9445375b68b5782af8ccb', 'sdf', 1);
INSERT INTO `user` VALUES (53, 'jack', 'm', '男', 'sfda', 'sfda', NULL, '2020-07-27 08:55:44', 0, '23', NULL, 0);
INSERT INTO `user` VALUES (54, '6', '6', '男', '14498986565', '1@con', '2020-07-30 09:10:13', '2020-08-04 14:21:13', 1, '0a3509f061247c713de5454f645b0730', 'dfs', 1);
INSERT INTO `user` VALUES (55, '77', '77', '男', '15544444777', '1@llfsd', '2020-07-30 09:40:48', '2020-07-30 09:40:48', 1, '4dc6922985b2bed2bab93810bf2cb3ec', 'dfs', 0);
INSERT INTO `user` VALUES (56, '8', '8', '男', '18882225555', '11@99.com', '2020-08-05 09:06:46', '2020-08-06 13:50:14', 1, 'c8efd8167423622852979adc046b9024', 'dd', 1);
INSERT INTO `user` VALUES (57, '9', '9', '男', '15588889999', '1@wertcom', '2020-08-05 09:18:45', '2020-08-06 14:54:36', 0, 'ed2bad4a6a1761888482df933eaa6e46', 'dd', 1);
INSERT INTO `user` VALUES (58, '10', '10', '男', '14478985555', '1@ert', '2020-08-05 09:24:07', '2020-08-05 09:24:07', 1, '1ba1901a745c04b3d60d269816df43bd', 'dd', 0);

SET FOREIGN_KEY_CHECKS = 1;
