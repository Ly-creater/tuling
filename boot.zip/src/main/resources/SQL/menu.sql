/*
 Navicat Premium Data Transfer

 Source Server         : database1
 Source Server Type    : MySQL
 Source Server Version : 80020
 Source Host           : localhost:3306
 Source Schema         : manager

 Target Server Type    : MySQL
 Target Server Version : 80020
 File Encoding         : 65001

 Date: 31/08/2020 22:15:03
*/

SET NAMES utf8mb4;
SET FOREIGN_KEY_CHECKS = 0;

-- ----------------------------
-- Table structure for menu
-- ----------------------------
DROP TABLE IF EXISTS `menu`;
CREATE TABLE `menu`  (
  `mid` int(0) NOT NULL AUTO_INCREMENT,
  `menuName` varchar(50) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL,
  `parentMenu` varchar(50) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  `menuType` varchar(50) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  `characteristic` varchar(100) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  `address` varchar(50) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  `orderNum` int(0) NULL DEFAULT NULL,
  `menuState` tinyint(1) NULL DEFAULT 1,
  `menuInfo` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  `menuVisible` tinyint(1) NOT NULL DEFAULT 1,
  `parentId` int(0) NULL DEFAULT NULL,
  PRIMARY KEY (`mid`) USING BTREE,
  UNIQUE INDEX `unique_name`(`menuName`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 21 CHARACTER SET = utf8 COLLATE = utf8_general_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of menu
-- ----------------------------
INSERT INTO `menu` VALUES (1, '系统管理', '', '目录', 'all', '/', 0, 1, '拥有所有权限的操作', 1, 0);
INSERT INTO `menu` VALUES (2, '用户管理', '系统管理', '菜单', 'user', '/user', 1, 1, '用户管理用户的权限', 1, 1);
INSERT INTO `menu` VALUES (3, '增加用户', '用户管理', '功能', 'user:add', '/user/add', 0, 1, '具有增加用户的权利', 1, 2);
INSERT INTO `menu` VALUES (4, '修改用户', '用户管理', '功能', 'user:update', '/user/update', 1, 1, '修改用户的权利', 1, 2);
INSERT INTO `menu` VALUES (5, '查看用户', '用户管理', '功能', 'user:search', '/user/select', 2, 1, '查看用户的权利', 1, 2);
INSERT INTO `menu` VALUES (6, '删除用户', '用户管理', '功能', 'user:delete', '/user/delete', 3, 1, '删除用户的权利', 1, 2);
INSERT INTO `menu` VALUES (7, '角色管理', '系统管理', '菜单', 'role', '/role', 2, 1, '具有管理角色的权利', 1, 1);
INSERT INTO `menu` VALUES (8, '增加角色', '角色管理', '功能', 'role:add', '/role/add', 0, 1, '具有新增角色的权利', 1, 7);
INSERT INTO `menu` VALUES (9, '修改角色', '角色管理', '功能', 'role:update', '/role/update', 1, 1, '具有修改角色的权利', 1, 7);
INSERT INTO `menu` VALUES (10, '查看角色', '角色管理', '功能', 'role:search', '/role/select', 2, 1, '具有查看角色的权利', 1, 7);
INSERT INTO `menu` VALUES (11, '删除角色', '角色管理', '功能', 'role:delete', 'role/delete', 3, 1, '具有删除角色的权利', 1, 7);
INSERT INTO `menu` VALUES (12, '菜单管理', '系统管理', '菜单', 'menu', '/menu', 3, 1, '具有菜单管理的权限', 1, 1);
INSERT INTO `menu` VALUES (13, '增加菜单', '菜单管理', '功能', 'menu:add', '/menu/add', 0, 1, '加油增加菜单的功能', 1, 12);
INSERT INTO `menu` VALUES (14, '查询菜单', '菜单管理', '功能', 'menu:search', '/menu/select', 1, 1, '具有查看菜单的权限', 1, 12);
INSERT INTO `menu` VALUES (15, '删除菜单', '菜单管理', '功能', 'menu:delete', '/menu/delete', 2, 1, '具有删除菜单的权限', 1, 12);
INSERT INTO `menu` VALUES (16, '修改菜单', '菜单管理', '功能', 'menu:update', '/menu/update', 3, 1, '具有修改菜单的权限', 1, 12);
INSERT INTO `menu` VALUES (17, '设置角色', '用户管理', '功能', 'user:role', '/user/role', 4, 1, '具有给用户设置角色的权利', 1, 2);
INSERT INTO `menu` VALUES (18, '设置权限', '角色管理', '功能', 'role:menu', '/role/menu', 4, 1, '具有给角色设置权限的权利', 1, 7);
INSERT INTO `menu` VALUES (19, '菜单测试', '系统管理', '菜单', 'test', 'test', 4, 1, 'df', 0, 1);
INSERT INTO `menu` VALUES (20, '用户角色管理', '系统管理', '菜单', 'userRole', '/user/userRole', 4, 1, NULL, 0, 1);
INSERT INTO `menu` VALUES (21, '1', '用户管理', '功能', '1', '1', 1, 1, '1', 0, 2);

SET FOREIGN_KEY_CHECKS = 1;
