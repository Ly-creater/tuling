/*
 Navicat Premium Data Transfer

 Source Server         : database1
 Source Server Type    : MySQL
 Source Server Version : 80020
 Source Host           : localhost:3306
 Source Schema         : manager

 Target Server Type    : MySQL
 Target Server Version : 80020
 File Encoding         : 65001

 Date: 31/08/2020 22:14:41
*/

SET NAMES utf8mb4;
SET FOREIGN_KEY_CHECKS = 0;

-- ----------------------------
-- Table structure for user_role
-- ----------------------------
DROP TABLE IF EXISTS `user_role`;
CREATE TABLE `user_role`  (
  `uid` int(0) UNSIGNED NOT NULL,
  `rid` int(0) NOT NULL,
  `startDate` date NULL DEFAULT NULL,
  `endDate` date NULL DEFAULT NULL,
  `urState` tinyint(1) NOT NULL DEFAULT 1,
  PRIMARY KEY (`uid`, `rid`) USING BTREE,
  INDEX `for_rid`(`rid`) USING BTREE
) ENGINE = InnoDB CHARACTER SET = utf8 COLLATE = utf8_general_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of user_role
-- ----------------------------
INSERT INTO `user_role` VALUES (28, 5, '2020-07-07', NULL, 1);
INSERT INTO `user_role` VALUES (46, 6, NULL, NULL, 1);
INSERT INTO `user_role` VALUES (47, 6, NULL, '2020-08-03', 0);
INSERT INTO `user_role` VALUES (47, 8, NULL, NULL, 1);
INSERT INTO `user_role` VALUES (48, 9, NULL, NULL, 1);
INSERT INTO `user_role` VALUES (49, 6, NULL, NULL, 1);
INSERT INTO `user_role` VALUES (49, 8, '2020-07-30', NULL, 1);
INSERT INTO `user_role` VALUES (52, 6, NULL, NULL, 1);
INSERT INTO `user_role` VALUES (52, 8, NULL, NULL, 1);
INSERT INTO `user_role` VALUES (58, 6, NULL, NULL, 1);

SET FOREIGN_KEY_CHECKS = 1;
