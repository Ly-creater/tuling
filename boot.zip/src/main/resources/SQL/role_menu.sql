/*
 Navicat Premium Data Transfer

 Source Server         : database1
 Source Server Type    : MySQL
 Source Server Version : 80020
 Source Host           : localhost:3306
 Source Schema         : manager

 Target Server Type    : MySQL
 Target Server Version : 80020
 File Encoding         : 65001

 Date: 31/08/2020 22:18:17
*/

SET NAMES utf8mb4;
SET FOREIGN_KEY_CHECKS = 0;

-- ----------------------------
-- Table structure for role_menu
-- ----------------------------
DROP TABLE IF EXISTS `role_menu`;
CREATE TABLE `role_menu`  (
  `rid` int(0) NOT NULL,
  `mid` int(0) NOT NULL,
  PRIMARY KEY (`rid`, `mid`) USING BTREE,
  INDEX `for_mrid`(`mid`) USING BTREE
) ENGINE = InnoDB CHARACTER SET = utf8 COLLATE = utf8_general_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of role_menu
-- ----------------------------
INSERT INTO `role_menu` VALUES (14, 2);
INSERT INTO `role_menu` VALUES (5, 3);
INSERT INTO `role_menu` VALUES (14, 3);
INSERT INTO `role_menu` VALUES (5, 4);
INSERT INTO `role_menu` VALUES (14, 4);
INSERT INTO `role_menu` VALUES (5, 5);
INSERT INTO `role_menu` VALUES (6, 5);
INSERT INTO `role_menu` VALUES (7, 5);
INSERT INTO `role_menu` VALUES (14, 5);
INSERT INTO `role_menu` VALUES (5, 6);
INSERT INTO `role_menu` VALUES (14, 6);
INSERT INTO `role_menu` VALUES (14, 7);
INSERT INTO `role_menu` VALUES (5, 8);
INSERT INTO `role_menu` VALUES (8, 8);
INSERT INTO `role_menu` VALUES (14, 8);
INSERT INTO `role_menu` VALUES (5, 9);
INSERT INTO `role_menu` VALUES (8, 9);
INSERT INTO `role_menu` VALUES (14, 9);
INSERT INTO `role_menu` VALUES (5, 10);
INSERT INTO `role_menu` VALUES (8, 10);
INSERT INTO `role_menu` VALUES (14, 10);
INSERT INTO `role_menu` VALUES (5, 11);
INSERT INTO `role_menu` VALUES (8, 11);
INSERT INTO `role_menu` VALUES (14, 11);
INSERT INTO `role_menu` VALUES (9, 12);
INSERT INTO `role_menu` VALUES (5, 13);
INSERT INTO `role_menu` VALUES (9, 13);
INSERT INTO `role_menu` VALUES (5, 14);
INSERT INTO `role_menu` VALUES (8, 14);
INSERT INTO `role_menu` VALUES (9, 14);
INSERT INTO `role_menu` VALUES (14, 14);
INSERT INTO `role_menu` VALUES (5, 15);
INSERT INTO `role_menu` VALUES (9, 15);
INSERT INTO `role_menu` VALUES (5, 16);
INSERT INTO `role_menu` VALUES (9, 16);
INSERT INTO `role_menu` VALUES (5, 17);
INSERT INTO `role_menu` VALUES (14, 17);
INSERT INTO `role_menu` VALUES (5, 18);
INSERT INTO `role_menu` VALUES (8, 18);
INSERT INTO `role_menu` VALUES (14, 18);

SET FOREIGN_KEY_CHECKS = 1;
