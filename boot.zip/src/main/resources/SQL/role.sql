/*
 Navicat Premium Data Transfer

 Source Server         : database1
 Source Server Type    : MySQL
 Source Server Version : 80020
 Source Host           : localhost:3306
 Source Schema         : manager

 Target Server Type    : MySQL
 Target Server Version : 80020
 File Encoding         : 65001

 Date: 31/08/2020 22:18:10
*/

SET NAMES utf8mb4;
SET FOREIGN_KEY_CHECKS = 0;

-- ----------------------------
-- Table structure for role
-- ----------------------------
DROP TABLE IF EXISTS `role`;
CREATE TABLE `role`  (
  `rid` int(0) NOT NULL AUTO_INCREMENT,
  `roleName` varchar(50) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  `roleCode` varchar(50) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  `roleState` tinyint(1) NULL DEFAULT NULL,
  `roleInfo` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  `roleVisible` tinyint(1) NOT NULL DEFAULT 1,
  PRIMARY KEY (`rid`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 14 CHARACTER SET = utf8 COLLATE = utf8_general_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of role
-- ----------------------------
INSERT INTO `role` VALUES (2, '2', '2', 1, NULL, 0);
INSERT INTO `role` VALUES (3, '3sf', NULL, 0, 'sdfgdsf', 0);
INSERT INTO `role` VALUES (4, '4', '4', 1, NULL, 0);
INSERT INTO `role` VALUES (5, '系统管理', 'all', 1, 'wertf', 1);
INSERT INTO `role` VALUES (6, '用户管理', 'user', 1, '具有管理用户的权利', 1);
INSERT INTO `role` VALUES (7, '用户查询', 'user/select', 1, '具有查询用户的权限', 0);
INSERT INTO `role` VALUES (8, '角色管理', 'role', 1, '具有管理角色的权限', 1);
INSERT INTO `role` VALUES (9, '菜单管理', 'menu', 1, '具有操作菜单的任何权限', 1);
INSERT INTO `role` VALUES (10, '菜单管理员助理', 'menu/help', 1, '只具有部分菜单管理角色', 0);
INSERT INTO `role` VALUES (11, '角色助手', 'user-help', 1, 'dsf', 0);
INSERT INTO `role` VALUES (12, '菜单助手', 'menu-help', 0, 'dsf', 0);
INSERT INTO `role` VALUES (13, '用户角色管理', 'userrole', 1, NULL, 0);
INSERT INTO `role` VALUES (14, 'jj', 'user/role', 1, 'f', 0);

SET FOREIGN_KEY_CHECKS = 1;
