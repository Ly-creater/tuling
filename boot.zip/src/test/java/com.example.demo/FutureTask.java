package com.example.demo;

import java.util.concurrent.*;

public class FutureTask {

        public static  void functionTimeoutTest2() throws  Exception{
            ExecutorService executorService= Executors.newSingleThreadExecutor();
            Future<String> future=executorService.submit(()->
                    {
                        Thread.sleep(10000);
                        return "success";
                    }
            );

            try{
                String result=future.get(5, TimeUnit.SECONDS);
                //String result=future.get(50,TimeUnit.SECONDS);
                System.out.println("result:"+result);
            }
            catch (TimeoutException e){
                System.out.println("超时了!");
            }
        }

}