package com.example.demo;

import com.example.demo.domain.Role;
import com.example.demo.domain.User;
import com.example.demo.domain.UserRole;
import com.example.demo.mapper.RoleMapper;
import com.example.demo.mapper.UserMapper;
import com.example.demo.mapper.UserRoleMapper;
import com.example.demo.service.UserService;
import com.example.demo.utils.JwtUtils;
import com.example.demo.vo.UserRoleSearchVo;
import io.jsonwebtoken.Claims;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import java.util.HashMap;
import java.util.List;
import java.util.concurrent.*;
import java.util.stream.IntStream;
import java.util.stream.Stream;

/**
 * @BelongsProject: sie
 * @BelongsPackage: PACKAGE_NAME
 * @Author: jkl
 * @CreateTime: 2020
 * @Description:
 */
@SpringBootTest
@RunWith(value = SpringJUnit4ClassRunner.class)
public class Test1 {
    @Autowired
    private UserMapper userMapper;
    @Autowired
    private RoleMapper roleMapper;
    @Autowired
    private UserService userService;
    @Autowired
    private JwtUtils jwtUtils;
    @Autowired
    private UserRoleMapper userRoleMapper;

    //@Test
    //public void ss(){
    //    String s ="{\"name\":\"1\",\"username\":\"1\",\"password\":\"1\",\"sex\":\"男\",\"mobile\":\"1\",\"email\":\"1\",\"createDate\":\"\",\"updateDate\":\"\",\"state\":\"1\",\"info\":\"1\"}";
    //    String ss="{\"name\":\"1\",\"username\":\"1\",\"password\":\"1\",\"sex\":\"男\",\"mobile\":\"1\",\"email\":\"1\",\"createDate\":\"\",\"updateDate\":\"\",\"state\":\"1\",\"info\":\"1\"}";
    //    System.out.println(user.toString());
    //}
    @Test
    public void sss() throws Exception {
        String admin = jwtUtils.generateToken(1, "admin");
        System.out.println(admin);
        admin="eyJhbGciOiJIUzI1NiJ9.eyJpZCI6NCwidXNlcm5hbWUiOiIxMSIsImV4cCI6MTU5MzQ4MDg3M30.Qw_ZoBHIhM6F_LQpcYrXuSS6v2_K5NPHDQv4JCGJQnI";
        Claims claims = jwtUtils.parseToken(admin);
        Object id = claims.get("id");
        Object username = claims.get("username");
        System.out.println(id+":"+username);
    }
    @Test
    public void fun04(){
        System.out.println(userMapper.selectById(43));
    }
    @Test
    public void fun05(){
        //User user = new User();
        //user.setUsername("1");
        //user.setName("m");
        //user.setState("有效");
        //List<User> users = userMapper.selectByUser(user);
        //System.out.println(users.toString());


    }
    @Test
    public void fun06(){
        User user = new User();
        user.setUsername("jack");
        user.setName("m");
        user.setPassword("23");
        user.setEmail("sfda");
        user.setMobile("sfda");
        user.setSex("男");
        user.setState(true);
       userMapper.insert(user);
    }
    @Test
    public void fun07(){
        //int[] a = {1,2,3,4};
        //List<Object> objects = Arrays.asList(a);
        //HashMap<String, Object> map = new HashMap<>();
        //map.put("uid",28);
        //map.put("rids",objects);
        //userMapper.insertUserAndRole(map);
    }
    @Test
    public void fun08(){
        User user = userMapper.selectById(28);
        List<Role> roles = user.getRoles();
        for(Role role:roles){
            System.out.println(role.toString());
        }
    }
    @Test
    public void fun09(){

    }
    @Test
    public void fun10(){
        //List<Role> roles = roleMapper.selectByRole(new Role());
        //for(Role role: roles){
        //    System.out.println(role);
        //}
          }

    @Test
    public void fun12(){
        Role role = roleMapper.selectById(1);
        System.out.println(role);
    }
    @Test
    public void fun13(){
        //System.out.println(new Md5Hash("4rty34343", "sielocalhost", 3).toString());
        //System.out.println(new Md5Hash("jack", "sielocalhost", 3).toString());
        //System.out.println(new Md5Hash("jackdsaf", "sielocalhost", 3).toString());
        //System.out.println(IdentityCode.getCode());
    }
    @Test
    public void fun14(){
        //原始类型流 IntStream LongStream DoubleStream  支持sum()，average()
        IntStream.range(1,10).forEach(System.out::println);
        IntStream.range(1,10).average().ifPresent(System.out::println);
        int sum = IntStream.range(1, 10).sum();
        System.out.println(sum);

        //常规对象流Stream

        //1.当且仅当存在终端操作时，中间操作操作才会被执行。
        Stream.of("d2", "a2", "b1", "b3", "c")
                .filter(s -> {
                    System.out.println("filter: " + s);
                    return true;
                })
                .forEach(s ->{
                    System.out.println(s);
                });


    }
    @Test
    public  void functionTimeoutTest2() throws  Exception{
        ExecutorService executorService= Executors.newSingleThreadExecutor();
        Future<String> future=executorService.submit(()->
                {
                    Thread.sleep(1000);
                    return "success";
                }
        );

        try{
            String result=future.get(5, TimeUnit.SECONDS);
            //String result=future.get(50,TimeUnit.SECONDS);
            System.out.println("result:"+result);
        }
        catch (TimeoutException e){
            System.out.println("超时了!");
        }
    }
    @Test
    public void fun(){
        UserRoleSearchVo userRoleSearchVo = new UserRoleSearchVo(28,null,0,5);
        List<UserRole> userRoles = userRoleMapper.selectSetRole(userRoleSearchVo);
        for(UserRole userRole:userRoles){
            System.out.println(userRole.getRole().getRoleName()+":"+userRole.getStartDate()+":"+userRole.getEndDate()+":"+userRole.getUrState() );
        }

    }
    @Test
    public void fun33(){
        HashMap<String, Object> map = new HashMap<>();
        map.put("id",28);
        map.put("username","");

        String userNameById = userService.getUserNameById(map);
        System.out.println(userNameById);
    }

}
